import dotenv from 'dotenv';
// Load environment variables FIRST before any other imports
dotenv.config();

import express from 'express';
import cors from 'cors';
import helmet from 'helmet';
import morgan from 'morgan';
import cookieParser from 'cookie-parser';
import fileUpload from 'express-fileupload';
import mongoose from 'mongoose';
import path from 'path';
import os from 'os';
import { fileURLToPath } from 'url';

// Import routes
import authRoutes from './routes/auth.routes.js';
import companyRoutes from './routes/company.routes.js';
import partnerRoutes from './routes/partner.routes.js';
import partnerCompanyRoutes from './routes/partnerCompany.routes.js';
import uploadRoutes from './routes/upload.routes.js';
import teamRoutes from './routes/team.routes.js';
import propertyRoutes from './routes/property.routes.js';
import visitRoutes from './routes/visit.routes.js';
import commissionRoutes from './routes/commission.routes.js';
import agreementRoutes from './routes/agreement.routes.js';
import notificationRoutes from './routes/notification.routes.js';
import officeRoutes from './routes/office.routes.js';

// Import middleware
import { errorHandler, notFound } from './middlewares/error.middleware.js';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const PORT = process.env.PORT || 5000;

// Security middleware
app.use(helmet({
  crossOriginResourcePolicy: { policy: 'cross-origin' }
}));

// CORS configuration
app.use(cors({
  origin: process.env.FRONTEND_URL || 'http://localhost:5173',
  credentials: true,
  methods: ['GET', 'POST', 'PUT', 'DELETE', 'PATCH', 'OPTIONS'],
  allowedHeaders: ['Content-Type', 'Authorization']
}));

// Body parsing middleware
app.use(express.json({ limit: '10mb' }));
app.use(express.urlencoded({ extended: true, limit: '10mb' }));
app.use(cookieParser());

// File upload middleware
app.use(fileUpload({
  useTempFiles: true,
  tempFileDir: os.tmpdir(),
  limits: { fileSize: parseInt(process.env.MAX_FILE_SIZE) || 5 * 1024 * 1024 }
}));

// Static files
app.use('/uploads', express.static(path.join(__dirname, '../uploads')));

// Logging
if (process.env.NODE_ENV === 'development') {
  app.use(morgan('dev'));
}

// Health check endpoint
app.get('/api/health', (req, res) => {
  res.status(200).json({
    success: true,
    message: 'Server is running',
    timestamp: new Date().toISOString(),
    environment: process.env.NODE_ENV || 'development'
  });
});

// API Routes
app.use('/api/auth', authRoutes);
app.use('/api/companies', companyRoutes);
app.use('/api/partners', partnerRoutes);
app.use('/api/partner-company', partnerCompanyRoutes);
app.use('/api/upload', uploadRoutes);
app.use('/api', teamRoutes);
app.use('/api/properties', propertyRoutes);
app.use('/api/visits', visitRoutes);
app.use('/api/commissions', commissionRoutes);
app.use('/api/agreements', agreementRoutes);
app.use('/api/notifications', notificationRoutes);
app.use('/api/offices', officeRoutes);

// TODO: Add other routes as modules are implemented
// app.use('/api/platform', platformRoutes);
// app.use('/api/company', companyRoutes);
// app.use('/api/partner-manager', partnerManagerRoutes);
// app.use('/api/property-manager', propertyManagerRoutes);
// app.use('/api/finance-manager', financeManagerRoutes);
// app.use('/api/legal-manager', legalManagerRoutes);
// app.use('/api/operations-manager', operationsManagerRoutes);
// app.use('/api/partner', partnerRoutes);

// 404 handler
app.use('/api', (req, res) => {
  res.status(404).json({
    success: false,
    message: `Route ${req.originalUrl} not found`
  });
});

// Global error handler
app.use(errorHandler);

// Database connection and server start
const startServer = async () => {
  try {
    if (process.env.MONGODB_URI) {
      await mongoose.connect(process.env.MONGODB_URI);
      console.log('✅ Connected to MongoDB');
    } else {
      console.log('⚠️ No MongoDB URI provided, running without database');
    }

    app.listen(PORT, () => {
      console.log(`🚀 Server running on port ${PORT}`);
      console.log(`📝 Environment: ${process.env.NODE_ENV || 'development'}`);
      console.log(`🔗 Health check: http://localhost:${PORT}/api/health`);
    });
  } catch (error) {
    console.error('❌ Server startup error:', error.message);
    process.exit(1);
  }
};

startServer();

export default app;