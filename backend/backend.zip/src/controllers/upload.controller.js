import { v2 as cloudinary } from 'cloudinary';
import { ApiError } from '../middlewares/error.middleware.js';

// Configure Cloudinary - load config from env
const getCloudinaryConfig = () => ({
  cloud_name: process.env.CLOUDINARY_CLOUD_NAME,
  api_key: process.env.CLOUDINARY_API_KEY,
  api_secret: process.env.CLOUDINARY_API_SECRET
});

/**
 * @desc    Upload document (KYC, agreements, etc.)
 * @route   POST /api/upload/document
 * @access  Private
 */
export const uploadDocument = async (req, res, next) => {
  try {
    // Configure Cloudinary
    cloudinary.config(getCloudinaryConfig());

    if (!req.files || !req.files.file) {
      throw new ApiError(400, 'Please upload a file');
    }

    const file = req.files.file;
    const folder = req.body.folder || 'documents';

    // Validate file type
    const allowedTypes = ['image/jpeg', 'image/png', 'image/jpg', 'application/pdf'];
    if (!allowedTypes.includes(file.mimetype)) {
      throw new ApiError(400, 'Only images and PDF files are allowed');
    }

    // Upload to Cloudinary
    // For PDFs and documents, use attachment: false to allow inline viewing in browser
    const uploadOptions = {
      folder: `channel-partner-portal/${folder}`,
      resource_type: 'auto'
    };

    // Set attachment: false for PDFs so they can be viewed inline in browser
    if (file.mimetype === 'application/pdf') {
      uploadOptions.attachment = false;
    }

    const result = await cloudinary.uploader.upload(file.tempFilePath, uploadOptions);

    res.status(200).json({
      success: true,
      message: 'File uploaded successfully',
      data: {
        url: result.secure_url,
        publicId: result.public_id,
        resourceType: result.resource_type,
        format: result.format,
        size: result.bytes
      }
    });
  } catch (error) {
    next(error);
  }
};

/**
 * @desc    Upload image
 * @route   POST /api/upload/image
 * @access  Private
 */
export const uploadImage = async (req, res, next) => {
  try {
    // Configure Cloudinary
    cloudinary.config(getCloudinaryConfig());

    if (!req.files || !req.files.file) {
      throw new ApiError(400, 'Please upload a file');
    }

    const file = req.files.file;
    const folder = req.body.folder || 'images';

    // Validate file type
    const allowedTypes = ['image/jpeg', 'image/png', 'image/jpg', 'image/webp'];
    if (!allowedTypes.includes(file.mimetype)) {
      throw new ApiError(400, 'Only image files are allowed');
    }

    // Upload to Cloudinary
    const result = await cloudinary.uploader.upload(file.tempFilePath, {
      folder: `channel-partner-portal/${folder}`,
      resource_type: 'image'
    });

    res.status(200).json({
      success: true,
      message: 'Image uploaded successfully',
      data: {
        url: result.secure_url,
        publicId: result.public_id,
        width: result.width,
        height: result.height,
        format: result.format
      }
    });
  } catch (error) {
    next(error);
  }
};

/**
 * @desc    Delete file from Cloudinary
 * @route   DELETE /api/upload/:publicId
 * @access  Private
 */
export const deleteFile = async (req, res, next) => {
  try {
    // Configure Cloudinary
    cloudinary.config(getCloudinaryConfig());

    const { publicId } = req.params;

    if (!publicId) {
      throw new ApiError(400, 'Public ID is required');
    }

    const result = await cloudinary.uploader.destroy(publicId);

    if (result.result === 'not found') {
      throw new ApiError(404, 'File not found');
    }

    res.status(200).json({
      success: true,
      message: 'File deleted successfully'
    });
  } catch (error) {
    next(error);
  }
};