import crypto from 'crypto';
import User from '../models/User.js';
import Company from '../models/Company.js';
import AgreementTemplate from '../models/AgreementTemplate.js';
import { generateToken, verifyToken } from '../utils/token.js';
import { ApiError } from '../middlewares/error.middleware.js';

/**
 * Generate slug from company name
 */
const generateSlug = (name) => {
  return name
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, '-')
    .replace(/(^-|-$)/g, '');
};

/**
 * Create default agreement templates for a new company
 */
const createDefaultAgreementTemplates = async (companyId, userId) => {
  const defaultTemplates = [
    {
      companyId,
      type: 'nda',
      name: 'Non-Disclosure Agreement (NDA)',
      isRequired: true,
      displayOrder: 1,
      createdBy: userId,
      content: `NON-DISCLOSURE AGREEMENT

This Non-Disclosure Agreement ("Agreement") is entered into as of {{date}} by and between:

DISCLOSING PARTY:
{{companyName}}
("Company")

RECEIVING PARTY:
{{partnerName}}
("Partner")

WHEREAS, the Company desires to share certain confidential information with the Partner for the purpose of establishing a business relationship for the marketing and sale of real estate properties;

NOW, THEREFORE, in consideration of the mutual covenants contained herein, the parties agree as follows:

1. DEFINITION OF CONFIDENTIAL INFORMATION
"Confidential Information" means any and all information or data that has or could have commercial value or other utility in the business in which Disclosing Party is engaged. If Confidential Information includes information belonging to a third party, the Disclosing Party will so identify such information.

2. OBLIGATIONS OF RECEIVING PARTY
Receiving Party shall:
a) Maintain the confidentiality of the Confidential Information and not disclose it to any third party
b) Use the Confidential Information only for the purposes contemplated by this Agreement
c) Restrict disclosure of Confidential Information to its employees who have a need to know

3. EXCLUSIONS
The obligations of confidentiality shall not apply to information that:
a) Is or becomes publicly known through no fault of the Receiving Party
b) Is already known to the Receiving Party prior to disclosure
c) Is independently developed by the Receiving Party
d) Is approved for release by written authorization of the Disclosing Party

4. TERM
This Agreement shall remain in effect for a period of three (3) years from the date of signing.

5. RETURN OF MATERIALS
Upon termination of this Agreement, or upon request of the Disclosing Party, the Receiving Party shall promptly return or destroy all Confidential Information.

IN WITNESS WHEREOF, the parties have executed this Agreement as of the date first written above.

Company: {{companyName}}
Signature: _________________________
Date: _________________________

Partner: {{partnerName}}
Signature: _________________________
Date: _________________________`
    },
    {
      companyId,
      type: 'cpa',
      name: 'Channel Partner Agreement',
      isRequired: true,
      displayOrder: 2,
      createdBy: userId,
      content: `CHANNEL PARTNER AGREEMENT

This Channel Partner Agreement ("Agreement") is entered into as of {{date}} by and between:

COMPANY:
{{companyName}}
("Company")

CHANNEL PARTNER:
{{partnerName}}
("Partner")

WHEREAS, the Company is engaged in the business of real estate development and wishes to engage Partners to market and sell its properties;

WHEREAS, the Partner has the necessary expertise and resources to market and sell real estate properties;

NOW, THEREFORE, in consideration of the mutual covenants contained herein, the parties agree as follows:

1. APPOINTMENT
The Company hereby appoints the Partner as a non-exclusive channel partner for the marketing and sale of the Company's properties, subject to the terms and conditions of this Agreement.

2. PARTNER'S RESPONSIBILITIES
The Partner shall:
a) Market and promote the Company's properties to potential buyers
b) Provide accurate information about the properties to prospective buyers
c) Facilitate site visits for interested buyers
d) Maintain professional conduct in all dealings with buyers and the Company
e) Comply with all applicable laws and regulations

3. COMMISSION
The Partner shall be entitled to commission on successful sales as per the Company's tier-based commission structure. Commission rates may vary based on the Partner's tier and property type.

4. TERM AND TERMINATION
This Agreement shall remain in effect until terminated by either party with thirty (30) days written notice. Upon termination, the Partner shall be entitled to commissions on sales completed prior to termination.

5. CONFIDENTIALITY
The Partner agrees to maintain the confidentiality of all proprietary information shared by the Company.

6. INDEPENDENT CONTRACTOR STATUS
The Partner is an independent contractor and not an employee, agent, or partner of the Company.

IN WITNESS WHEREOF, the parties have executed this Agreement as of the date first written above.

Company: {{companyName}}
Signature: _________________________
Date: _________________________

Partner: {{partnerName}}
Signature: _________________________
Date: _________________________`
    },
    {
      companyId,
      type: 'code_of_conduct',
      name: 'Code of Conduct',
      isRequired: true,
      displayOrder: 3,
      createdBy: userId,
      content: `CODE OF CONDUCT

This Code of Conduct applies to all Channel Partners associated with {{companyName}}.

By signing below, I, {{partnerName}}, agree to abide by the following standards of conduct:

1. PROFESSIONAL CONDUCT
a) I will conduct all business activities in a professional and ethical manner
b) I will treat all clients, colleagues, and Company representatives with respect
c) I will dress appropriately and present a professional image

2. HONESTY AND INTEGRITY
a) I will provide accurate and truthful information to clients about properties
b) I will not make false or misleading statements about properties or the Company
c) I will disclose all material facts that may affect a client's decision

3. COMPLIANCE WITH LAWS
a) I will comply with all applicable real estate laws and regulations
b) I will obtain and maintain any required licenses or registrations
c) I will not engage in any unlawful or fraudulent activities

4. CONFLICT OF INTEREST
a) I will disclose any potential conflicts of interest to the Company
b) I will not represent competing interests without prior disclosure

5. CONFIDENTIALITY
a) I will protect the confidentiality of client information
b) I will not share proprietary Company information with competitors

6. ANTI-BRIBERY AND CORRUPTION
a) I will not offer, give, or accept bribes or improper payments
b) I will report any instances of suspected corruption

7. DATA PROTECTION
a) I will handle personal data in accordance with applicable data protection laws
b) I will not misuse or share client data without proper authorization

VIOLATIONS
Violation of this Code of Conduct may result in termination of partnership, forfeiture of pending commissions, and/or legal action.

I acknowledge that I have read and understood this Code of Conduct and agree to abide by its terms.

Partner: {{partnerName}}
Signature: _________________________
Date: _________________________`
    },
    {
      companyId,
      type: 'gdpr_consent',
      name: 'Data Protection Consent (GDPR)',
      isRequired: true,
      displayOrder: 4,
      createdBy: userId,
      content: `DATA PROTECTION CONSENT FORM

In accordance with the General Data Protection Regulation (GDPR) and applicable data protection laws, we require your consent to process your personal data.

PERSONAL DATA COLLECTED:
- Name and contact details
- Business information
- Identification documents
- Communication records
- Transaction history

PURPOSES OF PROCESSING:
- Managing your partnership with {{companyName}}
- Processing commissions and payments
- Compliance with legal obligations
- Communication about properties and business updates
- Improving our services

YOUR RIGHTS:
You have the right to:
a) Access your personal data
b) Rectify inaccurate data
c) Erase your data (subject to legal retention requirements)
d) Restrict processing
e) Data portability
f) Object to processing
g) Withdraw consent at any time

DATA RETENTION:
Your data will be retained for the duration of your partnership and for a period of 7 years after termination, or as required by law.

DATA SHARING:
Your data may be shared with:
- Property developers and associated parties
- Regulatory authorities (as required)
- Payment processors
- Professional advisors

SECURITY:
We implement appropriate technical and organizational measures to protect your data.

CONSENT:
By signing below, I consent to the processing of my personal data as described above:

Partner Name: {{partnerName}}
Email: {{partnerEmail}}
Phone: {{partnerPhone}}

Signature: _________________________
Date: {{date}}`
    }
  ];

  try {
    await AgreementTemplate.insertMany(defaultTemplates);
  } catch (error) {
    console.error('Error creating default agreement templates:', error);
    // Don't throw error - company registration should succeed even if templates fail
  }
};

/**
 * @desc    Register new company (self-registration)
 * @route   POST /api/auth/register/company
 * @access  Public
 */
export const registerCompany = async (req, res, next) => {
  try {
    const {
      companyName,
      email,
      phone,
      website,
      regions,
      defaultCurrency,
      address,
      // SuperAdmin account
      firstName,
      lastName,
      password
    } = req.body;

    // Check if company email already exists
    const existingCompany = await Company.findOne({ email });
    if (existingCompany) {
      throw new ApiError(400, 'Company with this email already exists');
    }

    // Check if user email already exists
    const existingUser = await User.findOne({ email });
    if (existingUser) {
      throw new ApiError(400, 'User with this email already exists');
    }

    // Generate slug and check if it already exists
    const slug = generateSlug(companyName);
    const existingSlug = await Company.findOne({ slug });
    if (existingSlug) {
      throw new ApiError(400, 'A company with a similar name already exists. Please use a different name.');
    }

    // Create company
    const company = await Company.create({
      name: companyName,
      slug,
      email,
      phone,
      website,
      regions: regions || ['india'],
      defaultCurrency: defaultCurrency || 'INR',
      address,
      status: 'pending' // Needs platform admin approval
    });

    // Create company superadmin
    const user = await User.create({
      companyId: company._id,
      email,
      password,
      firstName,
      lastName,
      phone,
      role: 'company_superadmin',
      isEmailVerified: false
    });

    // Create default agreement templates for the new company
    await createDefaultAgreementTemplates(company._id, user._id);

    // Generate email verification token
    const verificationToken = user.generateEmailVerificationToken();
    await user.save({ validateBeforeSave: false });

    // TODO: Send verification email

    // Generate token
    const token = generateToken({ userId: user._id, companyId: company._id, role: user.role });

    res.status(201).json({
      success: true,
      message: 'Company registered successfully. Please verify your email.',
      data: {
        company: {
          id: company._id,
          name: company.name,
          email: company.email,
          status: company.status
        },
        user: {
          id: user._id,
          email: user.email,
          firstName: user.firstName,
          lastName: user.lastName,
          role: user.role
        },
        token
      }
    });
  } catch (error) {
    // Handle MongoDB duplicate key errors
    if (error.code === 11000) {
      const field = Object.keys(error.keyPattern)[0];
      if (field === 'email') {
        return next(new ApiError(400, 'Email already registered'));
      }
      if (field === 'slug') {
        return next(new ApiError(400, 'A company with a similar name already exists'));
      }
    }
    next(error);
  }
};

/**
 * @desc    Register new partner
 * @route   POST /api/auth/register/partner
 * @access  Public
 */
export const registerPartner = async (req, res, next) => {
  try {
    const {
      email,
      password,
      firstName,
      lastName,
      phone,
      // Partner profile
      companyName,
      companyType,
      operatingRegion,
      // Address
      address,
      // Contact person
      contactPerson,
      // Bank details
      bankDetails
    } = req.body;

    // Check if user already exists
    const existingUser = await User.findOne({ email });
    if (existingUser) {
      throw new ApiError(400, 'User with this email already exists');
    }

    // Create partner user (no company association yet)
    // Status is 'active' - partner can login immediately and browse companies
    // Approval happens at the partnership level when company approves their application
    const user = await User.create({
      email,
      password,
      firstName,
      lastName,
      phone,
      role: 'partner',
      partnerProfile: {
        companyName,
        companyType,
        operatingRegion,
        address,
        contactPerson,
        bankDetails,
        status: 'active'
      }
    });

    // Generate email verification token
    const verificationToken = user.generateEmailVerificationToken();
    await user.save({ validateBeforeSave: false });

    // TODO: Send verification email

    // Generate token (no companyId since partner hasn't joined any company yet)
    const token = generateToken({ userId: user._id, role: user.role });

    res.status(201).json({
      success: true,
      message: 'Partner registered successfully. After verifying your email, you can browse and apply to companies.',
      data: {
        user: {
          id: user._id,
          email: user.email,
          firstName: user.firstName,
          lastName: user.lastName,
          role: user.role,
          partnerProfile: user.partnerProfile
        },
        token
      }
    });
  } catch (error) {
    next(error);
  }
};

/**
 * @desc    Login user
 * @route   POST /api/auth/login
 * @access  Public
 */
export const login = async (req, res, next) => {
  try {
    const { email, password } = req.body;

    // Check if email and password are provided
    if (!email || !password) {
      throw new ApiError(400, 'Please provide email and password');
    }

    // Find user
    const user = await User.findOne({ email }).select('+password');

    if (!user) {
      throw new ApiError(401, 'Invalid credentials');
    }

    // Check if user is active
    if (!user.isActive) {
      throw new ApiError(401, 'Your account has been deactivated');
    }

    // Check password
    const isPasswordCorrect = await user.comparePassword(password);
    if (!isPasswordCorrect) {
      throw new ApiError(401, 'Invalid credentials');
    }

    // For company users (not partners without company), check if company is active
    if (user.role !== 'platform_admin' && user.role !== 'partner' && user.companyId) {
      const company = await Company.findById(user.companyId);
      if (!company) {
        throw new ApiError(401, 'Company not found');
      }
      if (company.status !== 'active') {
        throw new ApiError(401, 'Company account is not active');
      }
    }

    // For partners with a company, check if company is active
    if (user.role === 'partner' && user.companyId) {
      const company = await Company.findById(user.companyId);
      if (company && company.status !== 'active') {
        throw new ApiError(401, 'Company account is not active');
      }
    }

    // Update last login
    user.lastLogin = new Date();
    user.loginHistory.push({
      ip: req.ip,
      device: req.headers['user-agent'],
      browser: req.headers['user-agent'],
      timestamp: new Date()
    });
    await user.save({ validateBeforeSave: false });

    // Generate token
    const token = generateToken({
      userId: user._id,
      companyId: user.companyId,
      role: user.role
    });

    res.status(200).json({
      success: true,
      message: 'Login successful',
      data: {
        user: {
          id: user._id,
          email: user.email,
          firstName: user.firstName,
          lastName: user.lastName,
          role: user.role,
          companyId: user.companyId
        },
        token
      }
    });
  } catch (error) {
    next(error);
  }
};

/**
 * @desc    Get current user
 * @route   GET /api/auth/me
 * @access  Private
 */
export const getMe = async (req, res, next) => {
  try {
    const user = await User.findById(req.user._id);

    if (!user) {
      throw new ApiError(404, 'User not found');
    }

    // Get company if not platform admin
    let company = null;
    if (user.role !== 'platform_admin' && user.companyId) {
      company = await Company.findById(user.companyId);
    }

    res.status(200).json({
      success: true,
      data: {
        user,
        company
      }
    });
  } catch (error) {
    next(error);
  }
};

/**
 * @desc    Logout user
 * @route   POST /api/auth/logout
 * @access  Private
 */
export const logout = async (req, res, next) => {
  try {
    // In a stateless JWT system, logout is handled client-side
    // You could implement token blacklisting if needed

    res.status(200).json({
      success: true,
      message: 'Logged out successfully'
    });
  } catch (error) {
    next(error);
  }
};

/**
 * @desc    Forgot password
 * @route   POST /api/auth/forgot-password
 * @access  Public
 */
export const forgotPassword = async (req, res, next) => {
  try {
    const { email } = req.body;

    const user = await User.findOne({ email });

    if (!user) {
      throw new ApiError(404, 'User not found');
    }

    // Generate reset token
    const resetToken = user.generateResetPasswordToken();
    await user.save({ validateBeforeSave: false });

    // TODO: Send reset password email

    res.status(200).json({
      success: true,
      message: 'Password reset email sent',
      data: {
        resetToken // Remove in production
      }
    });
  } catch (error) {
    next(error);
  }
};

/**
 * @desc    Reset password
 * @route   POST /api/auth/reset-password/:token
 * @access  Public
 */
export const resetPassword = async (req, res, next) => {
  try {
    const { token } = req.params;
    const { password } = req.body;

    const user = await User.findOne({
      resetPasswordToken: token,
      resetPasswordExpire: { $gt: Date.now() }
    });

    if (!user) {
      throw new ApiError(400, 'Invalid or expired reset token');
    }

    // Set new password
    user.password = password;
    user.resetPasswordToken = undefined;
    user.resetPasswordExpire = undefined;
    await user.save();

    // Generate new token
    const newToken = generateToken({
      userId: user._id,
      companyId: user.companyId,
      role: user.role
    });

    res.status(200).json({
      success: true,
      message: 'Password reset successful',
      data: {
        token: newToken
      }
    });
  } catch (error) {
    next(error);
  }
};

/**
 * @desc    Verify email
 * @route   POST /api/auth/verify-email/:token
 * @access  Public
 */
export const verifyEmail = async (req, res, next) => {
  try {
    const { token } = req.params;

    const user = await User.findOne({
      emailVerificationToken: token,
      emailVerificationExpire: { $gt: Date.now() }
    });

    if (!user) {
      throw new ApiError(400, 'Invalid or expired verification token');
    }

    // Verify email
    user.isEmailVerified = true;
    user.emailVerificationToken = undefined;
    user.emailVerificationExpire = undefined;
    await user.save({ validateBeforeSave: false });

    res.status(200).json({
      success: true,
      message: 'Email verified successfully'
    });
  } catch (error) {
    next(error);
  }
};

/**
 * @desc    Refresh token
 * @route   POST /api/auth/refresh-token
 * @access  Private
 */
export const refreshToken = async (req, res, next) => {
  try {
    const user = await User.findById(req.user._id);

    if (!user) {
      throw new ApiError(404, 'User not found');
    }

    // Generate new token
    const token = generateToken({
      userId: user._id,
      companyId: user.companyId,
      role: user.role
    });

    res.status(200).json({
      success: true,
      data: { token }
    });
  } catch (error) {
    next(error);
  }
};

/**
 * @desc    Update user profile
 * @route   PUT /api/auth/profile
 * @access  Private
 */
export const updateProfile = async (req, res, next) => {
  try {
    const { firstName, lastName, phone } = req.body;

    const user = await User.findById(req.user._id);

    if (!user) {
      throw new ApiError(404, 'User not found');
    }

    // Update fields
    if (firstName) user.firstName = firstName;
    if (lastName) user.lastName = lastName;
    if (phone) user.phone = phone;

    await user.save();

    res.status(200).json({
      success: true,
      message: 'Profile updated successfully',
      data: { user }
    });
  } catch (error) {
    next(error);
  }
};

/**
 * @desc    Change password
 * @route   PUT /api/auth/password
 * @access  Private
 */
export const changePassword = async (req, res, next) => {
  try {
    const { currentPassword, newPassword } = req.body;

    const user = await User.findById(req.user._id).select('+password');

    if (!user) {
      throw new ApiError(404, 'User not found');
    }

    // Verify current password
    const isPasswordCorrect = await user.comparePassword(currentPassword);
    if (!isPasswordCorrect) {
      throw new ApiError(401, 'Current password is incorrect');
    }

    // Update password
    user.password = newPassword;
    await user.save();

    res.status(200).json({
      success: true,
      message: 'Password changed successfully'
    });
  } catch (error) {
    next(error);
  }
};