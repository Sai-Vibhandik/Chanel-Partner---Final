import express from 'express';
import {
  createCommission,
  getCompanyCommissions,
  getPartnerCommissions,
  getCommissionById,
  markAsPaid,
  cancelCommission,
  getCommissionStats
} from '../controllers/commission.controller.js';
import { protect, restrictTo } from '../middlewares/auth.middleware.js';

const router = express.Router();

// All routes require authentication
router.use(protect);

// ==================== FINANCE MANAGER ROUTES ====================

// Create commission (finance_manager, company_superadmin)
router.post(
  '/',
  restrictTo('finance_manager', 'company_superadmin'),
  createCommission
);

// Get company commissions (finance_manager, company_superadmin)
router.get(
  '/',
  restrictTo('finance_manager', 'company_superadmin'),
  getCompanyCommissions
);

// Get commission stats (finance_manager, company_superadmin)
router.get(
  '/stats',
  restrictTo('finance_manager', 'company_superadmin'),
  getCommissionStats
);

// ==================== PARTNER ROUTES ====================

// Get partner's own commissions
router.get(
  '/my',
  restrictTo('partner'),
  getPartnerCommissions
);

// ==================== PARAMETERIZED ROUTES ====================

// Get single commission details
router.get('/:id', getCommissionById);

// Mark as paid (finance_manager, company_superadmin)
router.put(
  '/:id/pay',
  restrictTo('finance_manager', 'company_superadmin'),
  markAsPaid
);

// Cancel commission (finance_manager, company_superadmin)
router.put(
  '/:id/cancel',
  restrictTo('finance_manager', 'company_superadmin'),
  cancelCommission
);

export default router;