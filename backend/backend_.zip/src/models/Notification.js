import mongoose from 'mongoose';

const notificationSchema = new mongoose.Schema({
  // Recipient
  recipientId: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User',
    required: true,
    index: true
  },

  // Notification type
  type: {
    type: String,
    enum: [
      // Agreements
      'agreement_update',
      'agreement_sign_required',
      'agreement_signed',
      'agreement_assigned',
      // KYC
      'kyc_approved',
      'kyc_rejected',
      'kyc_document_verified',
      'kyc_document_rejected',
      'kyc_status_updated',
      // Partnerships
      'partnership_approved',
      'partnership_rejected',
      'partnership_new_application',
      // Visits
      'visit_booked',
      'visit_approved',
      'visit_rejected',
      'visit_completed',
      'visit_cancelled',
      // Commissions
      'commission_paid',
      'commission_created',
      'commission_approved',
      // Properties
      'new_property',
      // System
      'system'
    ],
    required: true
  },

  // Title
  title: {
    type: String,
    required: true
  },

  // Message
  message: {
    type: String,
    required: true
  },

  // Related data
  data: {
    agreementId: { type: mongoose.Schema.Types.ObjectId, ref: 'AgreementTemplate' },
    partnershipId: { type: mongoose.Schema.Types.ObjectId, ref: 'PartnerCompany' },
    companyId: { type: mongoose.Schema.Types.ObjectId, ref: 'Company' },
    signatureId: { type: mongoose.Schema.Types.ObjectId, ref: 'AgreementSignature' },
    visitId: { type: mongoose.Schema.Types.ObjectId, ref: 'Visit' },
    propertyId: { type: mongoose.Schema.Types.ObjectId, ref: 'Property' },
    commissionId: { type: mongoose.Schema.Types.ObjectId, ref: 'Commission' },
    userId: { type: mongoose.Schema.Types.ObjectId, ref: 'User' }
  },

  // Link to navigate to
  link: {
    type: String
  },

  // Read status
  isRead: {
    type: Boolean,
    default: false
  },

  // When it was created
  createdAt: {
    type: Date,
    default: Date.now
  },

  // When it was read
  readAt: {
    type: Date
  }
});

// Index for efficient queries
notificationSchema.index({ recipientId: 1, isRead: 1, createdAt: -1 });

export default mongoose.model('Notification', notificationSchema);