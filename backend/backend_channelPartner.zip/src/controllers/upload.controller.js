import { v2 as cloudinary } from 'cloudinary';
import { ApiError } from '../middlewares/error.middleware.js';

// Configure Cloudinary - load config from env
const getCloudinaryConfig = () => ({
  cloud_name: process.env.CLOUDINARY_CLOUD_NAME,
  api_key: process.env.CLOUDINARY_API_KEY,
  api_secret: process.env.CLOUDINARY_API_SECRET
});

/**
 * Helper function to upload file buffer to Cloudinary using stream
 * This is more reliable for PDFs and other binary files
 */
const uploadBufferToCloudinary = (buffer, options) => {
  return new Promise((resolve, reject) => {
    // Create upload stream
    const uploadStream = cloudinary.uploader.upload_stream(
      options,
      (error, result) => {
        if (error) {
          console.error('Cloudinary upload stream error:', error);
          reject(error);
        } else {
          resolve(result);
        }
      }
    );

    // Write the buffer to the upload stream
    uploadStream.write(buffer);
    uploadStream.end();
  });
};

/**
 * @desc    Upload chat attachment (images, videos, documents)
 * @route   POST /api/upload/chat
 * @access  Private
 */
export const uploadChatAttachment = async (req, res, next) => {
  try {
    // Check if Cloudinary is configured
    if (!process.env.CLOUDINARY_CLOUD_NAME || !process.env.CLOUDINARY_API_KEY || !process.env.CLOUDINARY_API_SECRET) {
      // Return a mock response if Cloudinary is not configured
      console.warn('Cloudinary not configured, returning mock URL');
      return res.status(200).json({
        success: true,
        message: 'File uploaded (mock)',
        data: {
          url: `https://via.placeholder.com/400x300?text=${encodeURIComponent(req.files?.file?.name || 'File')}`,
          publicId: `mock_${Date.now()}`,
          resourceType: 'image',
          format: 'jpg',
          size: req.files?.file?.size || 0
        }
      });
    }

    // Configure Cloudinary
    cloudinary.config(getCloudinaryConfig());

    if (!req.files || !req.files.file) {
      throw new ApiError(400, 'Please upload a file');
    }

    const file = req.files.file;

    // Check if file buffer exists
    if (!file.data) {
      throw new ApiError(400, 'File data not received. Please try uploading again.');
    }

    // Determine resource type based on mimetype
    let resourceType = 'auto';
    if (file.mimetype.startsWith('video/')) {
      resourceType = 'video';
    } else if (file.mimetype.startsWith('image/')) {
      resourceType = 'image';
    }

    // Upload to Cloudinary using buffer
    const result = await uploadBufferToCloudinary(file.data, {
      folder: 'channel-partner-portal/chat',
      resource_type: resourceType
    });

    res.status(200).json({
      success: true,
      message: 'File uploaded successfully',
      data: {
        url: result.secure_url,
        publicId: result.public_id,
        resourceType: result.resource_type,
        format: result.format,
        size: result.bytes
      }
    });
  } catch (error) {
    console.error('Upload error:', error);
    next(error);
  }
};

/**
 * @desc    Upload document (KYC, agreements, etc.)
 * @route   POST /api/upload/document
 * @access  Private
 */
export const uploadDocument = async (req, res, next) => {
  try {
    // Check if Cloudinary is configured
    if (!process.env.CLOUDINARY_CLOUD_NAME || !process.env.CLOUDINARY_API_KEY || !process.env.CLOUDINARY_API_SECRET) {
      console.warn('Cloudinary not configured, returning mock URL');
      return res.status(200).json({
        success: true,
        message: 'File uploaded (mock)',
        data: {
          url: `https://via.placeholder.com/400x300?text=${encodeURIComponent(req.files?.file?.name || 'Document')}`,
          publicId: `mock_${Date.now()}`,
          resourceType: 'raw',
          format: 'pdf',
          size: req.files?.file?.size || 0
        }
      });
    }

    // Configure Cloudinary
    cloudinary.config(getCloudinaryConfig());

    if (!req.files || !req.files.file) {
      throw new ApiError(400, 'Please upload a file');
    }

    const file = req.files.file;
    const folder = req.body.folder || 'documents';

    // Validate file type
    const allowedTypes = ['image/jpeg', 'image/png', 'image/jpg', 'application/pdf'];
    if (!allowedTypes.includes(file.mimetype)) {
      throw new ApiError(400, 'Only images and PDF files are allowed');
    }

    // Validate file size (max 20MB)
    const maxSize = 20 * 1024 * 1024; // 20MB
    if (file.size > maxSize) {
      throw new ApiError(400, 'File size must be less than 20MB');
    }

    // Check if file buffer exists
    if (!file.data) {
      throw new ApiError(400, 'File data not received. Please try uploading again.');
    }

    // Log file info for debugging
    console.log('Uploading file:', {
      name: file.name,
      size: file.size,
      mimetype: file.mimetype,
      bufferSize: file.data ? file.data.length : 0
    });

    // Upload options for Cloudinary
    // Use 'raw' resource type for PDFs to ensure they're served correctly
    const uploadOptions = {
      folder: `channel-partner-portal/${folder}`,
      resource_type: file.mimetype === 'application/pdf' ? 'raw' : 'auto'
    };

    // Upload using buffer stream (more reliable for binary files)
    const result = await uploadBufferToCloudinary(file.data, uploadOptions);

    console.log('Upload successful:', {
      url: result.secure_url,
      publicId: result.public_id,
      resourceType: result.resource_type,
      bytes: result.bytes
    });

    res.status(200).json({
      success: true,
      message: 'File uploaded successfully',
      data: {
        url: result.secure_url,
        publicId: result.public_id,
        resourceType: result.resource_type,
        format: result.format,
        size: result.bytes
      }
    });
  } catch (error) {
    console.error('Upload document error:', error);
    next(error);
  }
};

/**
 * @desc    Upload image
 * @route   POST /api/upload/image
 * @access  Private
 */
export const uploadImage = async (req, res, next) => {
  try {
    // Check if Cloudinary is configured
    if (!process.env.CLOUDINARY_CLOUD_NAME || !process.env.CLOUDINARY_API_KEY || !process.env.CLOUDINARY_API_SECRET) {
      console.warn('Cloudinary not configured, returning mock URL');
      return res.status(200).json({
        success: true,
        message: 'Image uploaded (mock)',
        data: {
          url: `https://via.placeholder.com/400x300?text=${encodeURIComponent(req.files?.file?.name || 'Image')}`,
          publicId: `mock_${Date.now()}`,
          width: 400,
          height: 300,
          format: 'jpg'
        }
      });
    }

    // Configure Cloudinary
    cloudinary.config(getCloudinaryConfig());

    if (!req.files || !req.files.file) {
      throw new ApiError(400, 'Please upload a file');
    }

    const file = req.files.file;
    const folder = req.body.folder || 'images';

    // Validate file type
    const allowedTypes = ['image/jpeg', 'image/png', 'image/jpg', 'image/webp'];
    if (!allowedTypes.includes(file.mimetype)) {
      throw new ApiError(400, 'Only image files are allowed');
    }

    // Check if file buffer exists
    if (!file.data) {
      throw new ApiError(400, 'File data not received. Please try uploading again.');
    }

    // Upload to Cloudinary using buffer
    const result = await uploadBufferToCloudinary(file.data, {
      folder: `channel-partner-portal/${folder}`,
      resource_type: 'image'
    });

    res.status(200).json({
      success: true,
      message: 'Image uploaded successfully',
      data: {
        url: result.secure_url,
        publicId: result.public_id,
        width: result.width,
        height: result.height,
        format: result.format
      }
    });
  } catch (error) {
    console.error('Upload image error:', error);
    next(error);
  }
};

/**
 * @desc    Delete file from Cloudinary
 * @route   DELETE /api/upload/:publicId
 * @access  Private
 */
export const deleteFile = async (req, res, next) => {
  try {
    // Check if Cloudinary is configured
    if (!process.env.CLOUDINARY_CLOUD_NAME || !process.env.CLOUDINARY_API_KEY || !process.env.CLOUDINARY_API_SECRET) {
      return res.status(200).json({
        success: true,
        message: 'File deleted (mock)'
      });
    }

    // Configure Cloudinary
    cloudinary.config(getCloudinaryConfig());

    const { publicId } = req.params;

    if (!publicId) {
      throw new ApiError(400, 'Public ID is required');
    }

    const result = await cloudinary.uploader.destroy(publicId);

    if (result.result === 'not found') {
      throw new ApiError(404, 'File not found');
    }

    res.status(200).json({
      success: true,
      message: 'File deleted successfully'
    });
  } catch (error) {
    next(error);
  }
};