import PartnerCompany from '../models/PartnerCompany.js';
import User from '../models/User.js';
import Company from '../models/Company.js';
import AgreementTemplate from '../models/AgreementTemplate.js';
import AgreementSignature from '../models/AgreementSignature.js';
import Visit from '../models/Visit.js';
import Commission from '../models/Commission.js';
import Property from '../models/Property.js';
import { ApiError } from '../middlewares/error.middleware.js';
import { createNotification, createNotificationsForRecipients } from './notification.controller.js';
import {
  sendPartnershipApprovedEmail,
  sendPartnershipRejectedEmail,
  sendPartnershipApplicationEmail,
  sendKYCStatusEmail
} from '../services/email.service.js';

/**
 * @desc    Partner applies to join a company
 * @route   POST /api/partner-company/apply
 * @access  Private (Partner only)
 */
export const applyToCompany = async (req, res, next) => {
  try {
    const { companyId } = req.body;
    const partnerId = req.user._id;

    // Verify user is a partner
    if (req.user.role !== 'partner') {
      throw new ApiError(403, 'Only partners can apply to companies');
    }

    // Check if company exists and is active
    const company = await Company.findById(companyId);
    if (!company) {
      throw new ApiError(404, 'Company not found');
    }
    if (company.status !== 'active') {
      throw new ApiError(400, 'This company is not accepting applications');
    }

    // Check if already applied/joined
    const existing = await PartnerCompany.findOne({ partnerId, companyId });
    if (existing) {
      throw new ApiError(400, 'You have already applied to this company');
    }

    // Create partnership
    const partnership = await PartnerCompany.create({
      partnerId,
      companyId,
      status: 'pending',
      tier: 'bronze'
    });

    // Populate details
    await partnership.populate('companyId', 'name slug');

    // Send notification to company admins
    try {
      const admins = await User.find({
        companyId,
        role: { $in: ['company_superadmin', 'partner_manager'] }
      });

      if (admins.length > 0) {
        // Create in-app notifications
        await createNotificationsForRecipients({
          recipientIds: admins.map(a => a._id),
          type: 'partnership_new_application',
          title: 'New Partnership Application',
          message: `${req.user.firstName} ${req.user.lastName} has applied to join your company as a partner`,
          data: {
            partnershipId: partnership._id,
            companyId
          },
          link: `/partner-manager/partners/${partnership._id}`
        });

        // Send emails
        await sendPartnershipApplicationEmail(admins, req.user, company, partnership._id);
      }
    } catch (notifError) {
      console.error('Failed to send partnership application notification:', notifError.message);
    }

    res.status(201).json({
      success: true,
      message: 'Application submitted successfully',
      data: { partnership }
    });
  } catch (error) {
    next(error);
  }
};

/**
 * @desc    Get partner's companies (companies the partner has joined/applied to)
 * @route   GET /api/partner-company/my-companies
 * @access  Private (Partner only)
 */
export const getMyCompanies = async (req, res, next) => {
  try {
    const partnerId = req.user._id;

    const partnerships = await PartnerCompany.find({ partnerId })
      .populate('companyId', 'name slug logo regions address settings.tierPercentages')
      .sort({ createdAt: -1 });

    // Check for unsigned agreements for each partnership
    const partnershipsAgreements = await Promise.all(
      partnerships.map(async (partnership) => {
        // Get all required agreement templates for this company
        const templates = await AgreementTemplate.find({
          companyId: partnership.companyId._id,
          isActive: true,
          isRequired: true
        }).select('_id type version');

        // Get all signatures for this partnership (including expired ones from old versions)
        const allSignatures = await AgreementSignature.find({
          partnershipId: partnership._id
        }).select('agreementTemplateId version status');

        // Check if any required agreement is unsigned or needs re-signing
        const hasUnsignedAgreements = templates.some(template => {
          // Check if there's a valid signature for this exact template version
          const hasValidSignature = allSignatures.some(
            signed => signed.agreementTemplateId.toString() === template._id.toString() &&
                     signed.status === 'signed'
          );

          if (hasValidSignature) {
            return false; // Has valid signature, no need to sign
          }

          // Check if there's any signature for this template (even expired)
          const hasAnySignature = allSignatures.some(
            signed => signed.agreementTemplateId.toString() === template._id.toString()
          );

          // If no signature at all, needs to sign
          // If has signature but not valid (expired), needs to re-sign
          return true;
        });

        return {
          ...partnership.toObject(),
          hasUnsignedAgreements
        };
      })
    );

    res.status(200).json({
      success: true,
      data: { partnerships: partnershipsAgreements }
    });
  } catch (error) {
    next(error);
  }
};

/**
 * @desc    Get company's partners (for Partner Manager)
 * @route   GET /api/partner-company/company/:companyId/partners
 * @access  Private (Partner Manager, Company SuperAdmin)
 */
export const getCompanyPartners = async (req, res, next) => {
  try {
    const { companyId } = req.params;
    const { status, tier, search, page = 1, limit = 10 } = req.query;

    // Verify access
    if (req.user.role !== 'platform_admin' && req.user.companyId?.toString() !== companyId) {
      throw new ApiError(403, 'Access denied');
    }

    // Build query
    const query = { companyId };

    if (status) {
      query.status = status;
    }
    if (tier) {
      query.tier = tier;
    }

    // Execute query with pagination
    const skip = (parseInt(page) - 1) * parseInt(limit);
    const total = await PartnerCompany.countDocuments(query);

    const partnerships = await PartnerCompany.find(query)
      .populate('partnerId', 'firstName lastName email phone avatar')
      .sort({ createdAt: -1 })
      .skip(skip)
      .limit(parseInt(limit));

    // Filter by search if provided
    let filteredPartnerships = partnerships;
    if (search) {
      const searchRegex = new RegExp(search, 'i');
      filteredPartnerships = partnerships.filter(p =>
        searchRegex.test(p.partnerId?.firstName) ||
        searchRegex.test(p.partnerId?.lastName) ||
        searchRegex.test(p.partnerId?.email)
      );
    }

    // Filter out partnerships where the partner user was deleted (partnerId is null)
    filteredPartnerships = filteredPartnerships.filter(p => p.partnerId !== null);

    res.status(200).json({
      success: true,
      data: {
        partnerships: filteredPartnerships,
        pagination: {
          total,
          page: parseInt(page),
          pages: Math.ceil(total / parseInt(limit))
        }
      }
    });
  } catch (error) {
    next(error);
  }
};

/**
 * @desc    Get partnership details
 * @route   GET /api/partner-company/:id
 * @access  Private
 */
export const getPartnership = async (req, res, next) => {
  try {
    const { id } = req.params;

    const partnership = await PartnerCompany.findById(id)
      .populate('partnerId', 'firstName lastName email phone avatar partnerProfile')
      .populate('companyId', 'name slug logo regions address settings.tierPercentages')
      .populate('approvedBy', 'firstName lastName');

    if (!partnership) {
      throw new ApiError(404, 'Partnership not found');
    }

    // Verify access
    const isPartner = req.user._id.toString() === partnership.partnerId._id.toString();
    const isCompanyStaff = req.user.companyId?.toString() === partnership.companyId._id.toString() &&
                          ['company_superadmin', 'partner_manager', 'finance_manager'].includes(req.user.role);
    const isPlatformAdmin = req.user.role === 'platform_admin';

    if (!isPartner && !isCompanyStaff && !isPlatformAdmin) {
      throw new ApiError(403, 'Access denied');
    }

    res.status(200).json({
      success: true,
      data: { partnership }
    });
  } catch (error) {
    next(error);
  }
};

/**
 * @desc    Update partnership status (approve/suspend)
 * @route   PUT /api/partner-company/:id/status
 * @access  Private (Partner Manager, Company SuperAdmin)
 */
export const updatePartnershipStatus = async (req, res, next) => {
  try {
    const { id } = req.params;
    const { status, reason } = req.body;

    const partnership = await PartnerCompany.findById(id)
      .populate('companyId')
      .populate('partnerId');

    if (!partnership) {
      throw new ApiError(404, 'Partnership not found');
    }

    // Verify access
    if (req.user.role !== 'platform_admin' && req.user.companyId?.toString() !== partnership.companyId._id.toString()) {
      throw new ApiError(403, 'Access denied');
    }

    // Simplified status: pending -> active -> suspended
    const validStatuses = ['pending', 'active', 'suspended'];
    if (!validStatuses.includes(status)) {
      throw new ApiError(400, 'Invalid status. Use: pending, active, or suspended');
    }

    const previousStatus = partnership.status;

    // Update status
    partnership.status = status;

    if (status === 'active') {
      partnership.approvedAt = new Date();
      partnership.approvedBy = req.user._id;
    }

    if (reason) {
      partnership.adminNotes = reason;
    }

    await partnership.save();

    // Send notifications based on status change
    try {
      if (status === 'active' && previousStatus === 'pending') {
        // Partnership approved - notify partner
        await createNotification({
          recipientId: partnership.partnerId._id,
          type: 'partnership_approved',
          title: 'Partnership Approved',
          message: `Your partnership with ${partnership.companyId.name} has been approved!`,
          data: {
            partnershipId: partnership._id,
            companyId: partnership.companyId._id
          },
          link: '/partner/companies'
        });

        // Send approval email
        await sendPartnershipApprovedEmail(
          partnership.partnerId,
          partnership.companyId,
          partnership.tier
        );
      } else if (status === 'suspended') {
        // Partnership suspended/rejected - notify partner
        await createNotification({
          recipientId: partnership.partnerId._id,
          type: 'partnership_rejected',
          title: 'Partnership Suspended',
          message: `Your partnership with ${partnership.companyId.name} has been suspended.${reason ? ` Reason: ${reason}` : ''}`,
          data: {
            partnershipId: partnership._id,
            companyId: partnership.companyId._id
          },
          link: '/partner/companies'
        });

        // Send rejection/suspension email
        await sendPartnershipRejectedEmail(
          partnership.partnerId,
          partnership.companyId,
          reason || 'Your partnership has been suspended'
        );
      }
    } catch (notifError) {
      console.error('Failed to send partnership notification:', notifError.message);
    }

    res.status(200).json({
      success: true,
      message: `Partnership status updated to ${status}`,
      data: { partnership }
    });
  } catch (error) {
    next(error);
  }
};

/**
 * @desc    Update partnership tier
 * @route   PUT /api/partner-company/:id/tier
 * @access  Private (Partner Manager, Company SuperAdmin)
 */
export const updatePartnershipTier = async (req, res, next) => {
  try {
    const { id } = req.params;
    const { tier, commissionPercentage } = req.body;

    const partnership = await PartnerCompany.findById(id);

    if (!partnership) {
      throw new ApiError(404, 'Partnership not found');
    }

    // Verify access
    if (req.user.role !== 'platform_admin' && req.user.companyId?.toString() !== partnership.companyId.toString()) {
      throw new ApiError(403, 'Access denied');
    }

    const validTiers = ['bronze', 'silver', 'gold', 'platinum'];
    if (!validTiers.includes(tier)) {
      throw new ApiError(400, 'Invalid tier');
    }

    partnership.tier = tier;
    if (commissionPercentage !== undefined) {
      partnership.commissionPercentage = commissionPercentage;
    }

    await partnership.save();

    res.status(200).json({
      success: true,
      message: `Tier updated to ${tier}`,
      data: { partnership }
    });
  } catch (error) {
    next(error);
  }
};

/**
 * @desc    Upload KYC document for a partnership
 * @route   POST /api/partner-company/:id/kyc
 * @access  Private (Partner - own partnership only)
 */
export const uploadKYCForPartnership = async (req, res, next) => {
  try {
    const { id } = req.params;
    const { type, url, publicId, region } = req.body;

    const partnership = await PartnerCompany.findById(id);

    if (!partnership) {
      throw new ApiError(404, 'Partnership not found');
    }

    // Verify ownership
    if (req.user._id.toString() !== partnership.partnerId.toString()) {
      throw new ApiError(403, 'You can only upload documents for your own partnerships');
    }

    // Validate document type
    const validTypes = [
      'gst_certificate', 'pan_card', 'rera_certificate', 'address_proof', 'cancelled_cheque',
      'trade_license', 'rera_registration_card', 'emirates_id', 'passport_copy', 'visa_copy', 'other'
    ];
    if (!validTypes.includes(type)) {
      throw new ApiError(400, 'Invalid document type');
    }

    // Check if document of this type already exists
    const existingDocIndex = partnership.kycDocuments.findIndex(
      doc => doc.type === type && doc.region === region
    );

    const documentData = {
      type,
      url,
      publicId,
      region,
      uploadedAt: new Date(),
      status: 'pending'
    };

    if (existingDocIndex > -1) {
      // Update existing document
      partnership.kycDocuments[existingDocIndex] = documentData;
    } else {
      // Add new document
      partnership.kycDocuments.push(documentData);
    }

    // Update KYC status: pending → submitted when first document is uploaded
    // Also reset from rejected to submitted if re-uploading after rejection
    if (partnership.kycStatus === 'pending' || partnership.kycStatus === 'rejected') {
      partnership.kycStatus = 'submitted';
      partnership.kycSubmittedAt = new Date();
      partnership.kycVerifiedAt = undefined;
      partnership.rejectionReason = undefined;
    }

    await partnership.save();

    res.status(200).json({
      success: true,
      message: 'KYC document uploaded successfully',
      data: { partnership }
    });
  } catch (error) {
    next(error);
  }
};

/**
 * @desc    Get KYC summary for a partnership
 * @route   GET /api/partner-company/:id/kyc
 * @access  Private
 */
export const getKYCForPartnership = async (req, res, next) => {
  try {
    const { id } = req.params;

    const partnership = await PartnerCompany.findById(id)
      .populate('partnerId', 'firstName lastName email phone partnerProfile')
      .populate('companyId', 'name regions');

    if (!partnership) {
      throw new ApiError(404, 'Partnership not found');
    }

    // Verify access
    const isPartner = req.user._id.toString() === partnership.partnerId._id.toString();
    const isCompanyStaff = req.user.companyId?.toString() === partnership.companyId._id.toString();
    const isPlatformAdmin = req.user.role === 'platform_admin';

    if (!isPartner && !isCompanyStaff && !isPlatformAdmin) {
      throw new ApiError(403, 'Access denied');
    }

    // Get company's operating regions
    const company = await Company.findById(partnership.companyId._id);

    // Define required documents based on regions
    const getRequiredDocuments = (regions) => {
      const indiaDocs = [
        { type: 'pan_card', name: 'PAN Card', region: 'india', required: true },
        { type: 'gst_certificate', name: 'GST Certificate', region: 'india', required: true },
        { type: 'address_proof', name: 'Address Proof', region: 'india', required: true },
        { type: 'cancelled_cheque', name: 'Cancelled Cheque', region: 'india', required: true },
        { type: 'rera_certificate', name: 'RERA Certificate', region: 'india', required: false }
      ];

      const dubaiDocs = [
        { type: 'trade_license', name: 'Trade License', region: 'dubai', required: true },
        { type: 'rera_registration_card', name: 'RERA Registration Card', region: 'dubai', required: true },
        { type: 'emirates_id', name: 'Emirates ID', region: 'dubai', required: true },
        { type: 'passport_copy', name: 'Passport Copy', region: 'dubai', required: true },
        { type: 'visa_copy', name: 'Visa Copy', region: 'dubai', required: false }
      ];

      if (!regions || regions.length === 0) {
        return indiaDocs; // Default to India
      }

      let requiredDocs = [];
      if (regions.includes('india')) {
        requiredDocs = [...requiredDocs, ...indiaDocs];
      }
      if (regions.includes('dubai')) {
        requiredDocs = [...requiredDocs, ...dubaiDocs];
      }

      return requiredDocs;
    };

    const requiredDocs = getRequiredDocuments(company?.regions);

    // Populate verifiedBy for documents
    await partnership.populate('kycDocuments.verifiedBy', 'firstName lastName email');

    // Map uploaded documents
    const uploadedDocs = partnership.kycDocuments.map(doc => ({
      _id: doc._id,
      type: doc.type,
      region: doc.region,
      status: doc.status,
      uploadedAt: doc.uploadedAt,
      verifiedAt: doc.verifiedAt,
      url: doc.url,
      rejectionReason: doc.rejectionReason,
      verifiedBy: doc.verifiedBy
    }));

    // Get required document types (with region for matching)
    const requiredDocTypes = requiredDocs.filter(d => d.required);

    // Count verified required documents (matching both type AND region)
    const verifiedRequiredDocs = requiredDocTypes.filter(reqDoc =>
      uploadedDocs.some(doc =>
        doc.type === reqDoc.type && doc.region === reqDoc.region && doc.status === 'verified'
      )
    );

    // Build summary
    const summary = {
      kycStatus: partnership.kycStatus,
      totalRequired: requiredDocs.filter(d => d.required).length,
      uploaded: uploadedDocs.length,
      verified: verifiedRequiredDocs.length,
      pending: uploadedDocs.filter(d => d.status === 'pending').length,
      rejected: uploadedDocs.filter(d => d.status === 'rejected').length,
      requiredDocuments: requiredDocs.map(reqDoc => {
        const uploaded = uploadedDocs.find(d => d.type === reqDoc.type && d.region === reqDoc.region);
        return {
          ...reqDoc,
          uploaded: !!uploaded,
          document: uploaded || null
        };
      }),
      uploadedDocuments: uploadedDocs
    };

    res.status(200).json({
      success: true,
      data: { kycSummary: summary, partnership }
    });
  } catch (error) {
    next(error);
  }
};

/**
 * @desc    Verify/reject KYC document
 * @route   PUT /api/partner-company/:id/kyc/:documentId/verify
 * @access  Private (Partner Manager, Company SuperAdmin)
 */
export const verifyKYCForPartnership = async (req, res, next) => {
  try {
    const { id, documentId } = req.params;
    const { status, reason } = req.body;

    const partnership = await PartnerCompany.findById(id);

    if (!partnership) {
      throw new ApiError(404, 'Partnership not found');
    }

    // Verify access
    if (req.user.role !== 'platform_admin' && req.user.companyId?.toString() !== partnership.companyId.toString()) {
      throw new ApiError(403, 'Access denied');
    }

    const document = partnership.kycDocuments.find(doc => doc._id.toString() === documentId);

    if (!document) {
      throw new ApiError(404, 'Document not found');
    }

    // Update document status
    document.status = status;
    if (status === 'verified') {
      document.verifiedAt = new Date();
      document.verifiedBy = req.user._id;
      document.rejectionReason = undefined;
    }
    if (status === 'rejected' && reason) {
      document.rejectionReason = reason;
      document.verifiedAt = undefined;
      document.verifiedBy = undefined;
    }

    // Mark the kycDocuments array as modified so Mongoose detects the change
    partnership.markModified('kycDocuments');

    // Get company to determine required documents
    const company = await Company.findById(partnership.companyId);
    const regions = company?.regions || ['india'];

    // Define required documents per region
    const requiredDocsPerRegion = {
      india: [
        { type: 'pan_card', region: 'india' },
        { type: 'gst_certificate', region: 'india' },
        { type: 'address_proof', region: 'india' },
        { type: 'cancelled_cheque', region: 'india' }
      ],
      dubai: [
        { type: 'trade_license', region: 'dubai' },
        { type: 'rera_registration_card', region: 'dubai' },
        { type: 'emirates_id', region: 'dubai' },
        { type: 'passport_copy', region: 'dubai' }
      ]
    };

    // Get required documents for company's regions
    const requiredDocs = [];
    for (const region of regions) {
      if (requiredDocsPerRegion[region]) {
        requiredDocs.push(...requiredDocsPerRegion[region]);
      }
    }

    // If no regions defined, default to India
    if (requiredDocs.length === 0) {
      requiredDocs.push(...requiredDocsPerRegion.india);
    }

    // Check if all required documents are verified (matching both type AND region)
    const allRequiredVerified = requiredDocs.every(reqDoc => {
      return partnership.kycDocuments.some(
        doc => doc.type === reqDoc.type && doc.region === reqDoc.region && doc.status === 'verified'
      );
    });

    // Check if any required document is rejected
    const anyRequiredRejected = requiredDocs.some(reqDoc => {
      return partnership.kycDocuments.some(
        doc => doc.type === reqDoc.type && doc.region === reqDoc.region && doc.status === 'rejected'
      );
    });

    // Update KYC status based on document status
    if (anyRequiredRejected) {
      // If any required document is rejected, KYC status is rejected
      partnership.kycStatus = 'rejected';
      partnership.rejectionReason = 'One or more documents rejected';
      partnership.kycVerifiedAt = undefined;
    } else if (allRequiredVerified && partnership.kycDocuments.length > 0) {
      // If all required documents are verified, KYC status is verified
      partnership.kycStatus = 'verified';
      partnership.kycVerifiedAt = new Date();
      partnership.rejectionReason = undefined;
    } else {
      // Otherwise, KYC status remains submitted (documents pending review)
      partnership.kycStatus = 'submitted';
      partnership.kycVerifiedAt = undefined;
    }

    await partnership.save();

    // Send notification to partner about document verification
    try {
      const [partner, company] = await Promise.all([
        User.findById(partnership.partnerId),
        Company.findById(partnership.companyId)
      ]);

      if (partner) {
        // Notify about document verification
        await createNotification({
          recipientId: partner._id,
          type: status === 'verified' ? 'kyc_document_verified' : 'kyc_document_rejected',
          title: status === 'verified' ? 'KYC Document Verified' : 'KYC Document Rejected',
          message: status === 'verified'
            ? `Your ${document.type.replace(/_/g, ' ')} document has been verified.`
            : `Your ${document.type.replace(/_/g, ' ')} document was rejected.${reason ? ` Reason: ${reason}` : ''}`,
          data: {
            partnershipId: partnership._id,
            companyId: partnership.companyId
          },
          link: `/partner/company/${partnership._id}`
        });

        // If all documents verified, send additional notification
        if (partnership.kycStatus === 'verified') {
          await sendKYCStatusEmail(partner, company, 'verified', 'All your documents have been verified. Your KYC is now complete.');
        } else if (partnership.kycStatus === 'rejected') {
          await sendKYCStatusEmail(partner, company, 'rejected', partnership.rejectionReason || 'One or more documents were rejected');
        }
      }
    } catch (notifError) {
      console.error('Failed to send document verification notification:', notifError.message);
    }

    res.status(200).json({
      success: true,
      message: `Document ${status === 'verified' ? 'verified' : 'rejected'} successfully`,
      data: { partnership }
    });
  } catch (error) {
    next(error);
  }
};

/**
 * @desc    Update KYC status manually (approve/reject KYC)
 * @route   PUT /api/partner-company/:id/kyc/status
 * @access  Private (Partner Manager, Property Manager, Company SuperAdmin, Platform Admin)
 */
export const updateKYCStatus = async (req, res, next) => {
  try {
    const { id } = req.params;
    const { status, reason } = req.body;

    if (!['verified', 'rejected'].includes(status)) {
      throw new ApiError(400, 'Status must be either "verified" or "rejected"');
    }

    const partnership = await PartnerCompany.findById(id)
      .populate('companyId', 'name')
      .populate('partnerId', 'firstName lastName email');

    if (!partnership) {
      throw new ApiError(404, 'Partnership not found');
    }

    // Verify access
    if (req.user.role !== 'platform_admin' && req.user.companyId?.toString() !== partnership.companyId.toString()) {
      throw new ApiError(403, 'Access denied');
    }

    partnership.kycStatus = status;

    if (status === 'verified') {
      partnership.kycVerifiedAt = new Date();
    } else if (status === 'rejected') {
      partnership.rejectionReason = reason || 'KYC rejected';
    }

    await partnership.save();

    // Send notification to partner
    try {
      await createNotification({
        recipientId: partnership.partnerId._id,
        type: status === 'verified' ? 'kyc_approved' : 'kyc_rejected',
        title: status === 'verified' ? 'KYC Approved' : 'KYC Rejected',
        message: status === 'verified'
          ? `Your KYC verification with ${partnership.companyId.name} has been approved.`
          : `Your KYC verification with ${partnership.companyId.name} has been rejected.${reason ? ` Reason: ${reason}` : ''}`,
        data: {
          partnershipId: partnership._id,
          companyId: partnership.companyId._id
        },
        link: `/partner/company/${partnership._id}`
      });

      // Send email
      await sendKYCStatusEmail(
        partnership.partnerId,
        partnership.companyId,
        status,
        reason
      );
    } catch (notifError) {
      console.error('Failed to send KYC status notification:', notifError.message);
    }

    res.status(200).json({
      success: true,
      message: `KYC ${status === 'verified' ? 'approved' : 'rejected'} successfully`,
      data: { partnership }
    });
  } catch (error) {
    next(error);
  }
};

/**
 * @desc    Get all pending KYC reviews for a company (Admin)
 * @route   GET /api/partner-company/kyc-reviews
 * @access  Private (Partner Manager, Company SuperAdmin)
 */
export const getKYCReviews = async (req, res, next) => {
  try {
    const { status, page = 1, limit = 20, search } = req.query;
    const companyId = req.user.companyId;

    // Build query
    const query = { companyId };

    // Get all partnerships with their KYC documents
    const partnerships = await PartnerCompany.find(query)
      .populate('partnerId', 'firstName lastName email phone')
      .populate('companyId', 'name')
      .sort({ createdAt: -1 });

    // Filter by search if provided
    let filteredPartnerships = partnerships;

    // Filter out partnerships with deleted partners (null partnerId)
    filteredPartnerships = filteredPartnerships.filter(p => p.partnerId !== null);

    if (search) {
      const searchRegex = new RegExp(search, 'i');
      filteredPartnerships = filteredPartnerships.filter(p =>
        searchRegex.test(p.partnerId?.firstName) ||
        searchRegex.test(p.partnerId?.lastName) ||
        searchRegex.test(p.partnerId?.email)
      );
    }

    // Get company for regions
    const company = await Company.findById(companyId);
    const regions = company?.regions || ['india'];

    // Define required documents per region
    const requiredDocsPerRegion = {
      india: [
        { type: 'pan_card', name: 'PAN Card', required: true },
        { type: 'gst_certificate', name: 'GST Certificate', required: true },
        { type: 'address_proof', name: 'Address Proof', required: true },
        { type: 'cancelled_cheque', name: 'Cancelled Cheque', required: true },
        { type: 'rera_certificate', name: 'RERA Certificate', required: false }
      ],
      dubai: [
        { type: 'trade_license', name: 'Trade License', required: true },
        { type: 'rera_registration_card', name: 'RERA Registration Card', required: true },
        { type: 'emirates_id', name: 'Emirates ID', required: true },
        { type: 'passport_copy', name: 'Passport Copy', required: true },
        { type: 'visa_copy', name: 'Visa Copy', required: false }
      ]
    };

    // Get required docs for company's regions
    let requiredDocs = [];
    for (const region of regions) {
      requiredDocs = [...requiredDocs, ...(requiredDocsPerRegion[region] || []).map(d => ({ ...d, region }))];
    }

    // Build KYC review list
    const kycReviews = filteredPartnerships.map(partnership => {
      const partner = partnership.partnerId;
      const docs = partnership.kycDocuments || [];

      // Build document status
      const documents = requiredDocs.map(reqDoc => {
        const uploaded = docs.find(d => d.type === reqDoc.type && d.region === reqDoc.region);
        return {
          type: reqDoc.type,
          name: reqDoc.name,
          region: reqDoc.region,
          required: reqDoc.required,
          status: uploaded?.status || 'not_uploaded',
          uploadedAt: uploaded?.uploadedAt,
          verifiedAt: uploaded?.verifiedAt,
          verifiedBy: uploaded?.verifiedBy,
          rejectionReason: uploaded?.rejectionReason,
          documentId: uploaded?._id,
          url: uploaded?.url
        };
      });

      // Count by status
      const statusCounts = {
        verified: documents.filter(d => d.status === 'verified').length,
        pending: documents.filter(d => d.status === 'pending').length,
        rejected: documents.filter(d => d.status === 'rejected').length,
        notUploaded: documents.filter(d => d.status === 'not_uploaded').length
      };

      // Calculate completion percentage
      const requiredCount = documents.filter(d => d.required).length;
      const verifiedRequired = documents.filter(d => d.required && d.status === 'verified').length;
      const completionPercentage = Math.round((verifiedRequired / requiredCount) * 100);

      return {
        partnershipId: partnership._id,
        partner: {
          _id: partner?._id,
          firstName: partner?.firstName,
          lastName: partner?.lastName,
          email: partner?.email,
          phone: partner?.phone
        },
        partnershipStatus: partnership.status,
        tier: partnership.tier,
        kycStatus: partnership.kycStatus,
        kycSubmittedAt: partnership.kycSubmittedAt,
        documents,
        statusCounts,
        completionPercentage,
        allRequiredVerified: verifiedRequired === requiredCount
      };
    });

    // Filter by KYC status if provided
    let result = kycReviews;
    if (status === 'pending') {
      result = kycReviews.filter(r => r.statusCounts.pending > 0 || r.statusCounts.notUploaded > 0);
    } else if (status === 'verified') {
      result = kycReviews.filter(r => r.allRequiredVerified);
    } else if (status === 'rejected') {
      result = kycReviews.filter(r => r.statusCounts.rejected > 0);
    }

    // Pagination
    const skip = (parseInt(page) - 1) * parseInt(limit);
    const total = result.length;
    const paginatedResult = result.slice(skip, skip + parseInt(limit));

    res.status(200).json({
      success: true,
      data: {
        reviews: paginatedResult,
        requiredDocs,
        regions,
        pagination: {
          total,
          page: parseInt(page),
          pages: Math.ceil(total / parseInt(limit))
        }
      }
    });
  } catch (error) {
    next(error);
  }
};

/**
 * @desc    Leave a company (Partner)
 * @route   DELETE /api/partner-company/:id
 * @access  Private (Partner - own partnership only)
 */
export const leaveCompany = async (req, res, next) => {
  try {
    const { id } = req.params;

    const partnership = await PartnerCompany.findById(id);

    if (!partnership) {
      throw new ApiError(404, 'Partnership not found');
    }

    // Verify ownership
    if (req.user._id.toString() !== partnership.partnerId.toString()) {
      throw new ApiError(403, 'You can only leave your own partnerships');
    }

    // Don't delete, just set status to suspended
    partnership.status = 'suspended';
    await partnership.save();

    res.status(200).json({
      success: true,
      message: 'You have left the company'
    });
  } catch (error) {
    next(error);
  }
};

/**
 * @desc    Get partner performance report
 * @route   GET /api/partners/performance-report
 * @access  Private (Partner Manager, Company SuperAdmin)
 */
export const getPartnerPerformanceReport = async (req, res, next) => {
  try {
    const { startDate, endDate, tier, sortBy = 'totalVisits', sortOrder = 'desc' } = req.query;
    const companyId = req.user.companyId;

    if (!companyId) {
      return res.status(200).json({
        success: true,
        data: { partners: [], summary: { totalPartners: 0, totalVisits: 0, totalCommissions: 0, avgConversionRate: 0 } }
      });
    }

    // Build date filter
    const dateFilter = {};
    if (startDate || endDate) {
      dateFilter.createdAt = {};
      if (startDate) dateFilter.createdAt.$gte = new Date(startDate);
      if (endDate) {
        const end = new Date(endDate);
        end.setHours(23, 59, 59, 999);
        dateFilter.createdAt.$lte = end;
      }
    }

    // Get all partnerships for the company
    const matchFilter = { companyId, status: 'active', ...dateFilter };
    if (tier && ['bronze', 'silver', 'gold', 'platinum'].includes(tier)) {
      matchFilter.tier = tier;
    }

    // Aggregate partner performance
    const partnerPerformance = await PartnerCompany.aggregate([
      { $match: matchFilter },
      {
        $lookup: {
          from: 'users',
          localField: 'partnerId',
          foreignField: '_id',
          as: 'partner'
        }
      },
      { $unwind: '$partner' },
      {
        $lookup: {
          from: 'visits',
          let: { partnershipId: '$_id' },
          pipeline: [
            { $match: { $expr: { $eq: ['$partnershipId', '$$partnershipId'] } } },
            {
              $group: {
                _id: null,
                totalVisits: { $sum: 1 },
                completedVisits: { $sum: { $cond: [{ $eq: ['$status', 'completed'] }, 1, 0] } },
                cancelledVisits: { $sum: { $cond: [{ $eq: ['$status', 'cancelled'] }, 1, 0] } },
                pendingVisits: { $sum: { $cond: [{ $eq: ['$status', 'pending'] }, 1, 0] } }
              }
            }
          ],
          as: 'visitStats'
        }
      },
      {
        $lookup: {
          from: 'commissions',
          let: { partnershipId: '$_id' },
          pipeline: [
            { $match: { $expr: { $eq: ['$partnershipId', '$$partnershipId'] } } },
            {
              $group: {
                _id: null,
                totalCommissions: { $sum: '$commission.calculatedAmount' },
                paidCommissions: { $sum: { $cond: [{ $eq: ['$status', 'paid'] }, '$commission.calculatedAmount', 0] } },
                pendingCommissions: { $sum: { $cond: [{ $eq: ['$status', 'pending'] }, '$commission.calculatedAmount', 0] } },
                commissionCount: { $sum: 1 }
              }
            }
          ],
          as: 'commissionStats'
        }
      },
      {
        $project: {
          partnershipId: '$_id',
          partnerId: '$partnerId',
          partnerName: { $concat: ['$partner.firstName', ' ', '$partner.lastName'] },
          partnerEmail: '$partner.email',
          partnerPhone: '$partner.phone',
          tier: 1,
          status: 1,
          kycStatus: 1,
          totalVisits: { $ifNull: [{ $arrayElemAt: ['$visitStats.totalVisits', 0] }, 0] },
          completedVisits: { $ifNull: [{ $arrayElemAt: ['$visitStats.completedVisits', 0] }, 0] },
          cancelledVisits: { $ifNull: [{ $arrayElemAt: ['$visitStats.cancelledVisits', 0] }, 0] },
          pendingVisits: { $ifNull: [{ $arrayElemAt: ['$visitStats.pendingVisits', 0] }, 0] },
          totalCommissions: { $ifNull: [{ $arrayElemAt: ['$commissionStats.totalCommissions', 0] }, 0] },
          paidCommissions: { $ifNull: [{ $arrayElemAt: ['$commissionStats.paidCommissions', 0] }, 0] },
          pendingCommissions: { $ifNull: [{ $arrayElemAt: ['$commissionStats.pendingCommissions', 0] }, 0] },
          commissionCount: { $ifNull: [{ $arrayElemAt: ['$commissionStats.commissionCount', 0] }, 0] },
          createdAt: 1,
          approvedAt: 1
        }
      },
      {
        $addFields: {
          conversionRate: {
            $cond: {
              if: { $gt: ['$totalVisits', 0] },
              then: { $multiply: [{ $divide: ['$completedVisits', '$totalVisits'] }, 100] },
              else: 0
            }
          }
        }
      }
    ]);

    // Calculate summary
    const summary = {
      totalPartners: partnerPerformance.length,
      totalVisits: partnerPerformance.reduce((sum, p) => sum + p.totalVisits, 0),
      completedVisits: partnerPerformance.reduce((sum, p) => sum + p.completedVisits, 0),
      totalCommissions: partnerPerformance.reduce((sum, p) => sum + p.totalCommissions, 0),
      paidCommissions: partnerPerformance.reduce((sum, p) => sum + p.paidCommissions, 0),
      pendingCommissions: partnerPerformance.reduce((sum, p) => sum + p.pendingCommissions, 0),
      avgConversionRate: partnerPerformance.length > 0
        ? partnerPerformance.reduce((sum, p) => sum + p.conversionRate, 0) / partnerPerformance.length
        : 0
    };

    // Tier breakdown
    const tierBreakdown = await PartnerCompany.aggregate([
      { $match: { companyId, status: 'active' } },
      {
        $group: {
          _id: '$tier',
          count: { $sum: 1 }
        }
      },
      { $sort: { count: -1 } }
    ]);

    // Sort partner performance
    const sortField = sortBy || 'totalVisits';
    const sortDirection = sortOrder === 'asc' ? 1 : -1;
    partnerPerformance.sort((a, b) => {
      const aVal = a[sortField] || 0;
      const bVal = b[sortField] || 0;
      return (aVal - bVal) * sortDirection;
    });

    res.status(200).json({
      success: true,
      data: {
        partners: partnerPerformance,
        summary,
        tierBreakdown: tierBreakdown.reduce((acc, t) => {
          acc[t._id] = t.count;
          return acc;
        }, { bronze: 0, silver: 0, gold: 0, platinum: 0 })
      }
    });
  } catch (error) {
    next(error);
  }
};

/**
 * @desc    Get commission report
 * @route   GET /api/commissions/commission-report
 * @access  Private (Finance Manager, Partner Manager, Company SuperAdmin)
 */
export const getCommissionReport = async (req, res, next) => {
  try {
    const { startDate, endDate, status, tier, groupBy = 'month' } = req.query;
    const companyId = req.user.companyId;

    if (!companyId) {
      return res.status(200).json({
        success: true,
        data: {
          summary: { totalAmount: 0, paidAmount: 0, pendingAmount: 0, approvedAmount: 0, totalCount: 0 },
          byStatus: [],
          byTier: [],
          byPartner: [],
          byPeriod: []
        }
      });
    }

    // Build match filter
    const matchFilter = { companyId: companyId };

    // Date filter
    if (startDate || endDate) {
      matchFilter.createdAt = {};
      if (startDate) matchFilter.createdAt.$gte = new Date(startDate);
      if (endDate) {
        const end = new Date(endDate);
        end.setHours(23, 59, 59, 999);
        matchFilter.createdAt.$lte = end;
      }
    }

    // Status filter
    if (status && ['pending', 'approved', 'paid', 'cancelled'].includes(status)) {
      matchFilter.status = status;
    }

    // Get all commissions with partner info
    const commissions = await Commission.find(matchFilter)
      .populate('partner', 'firstName lastName email partnerProfile.tier')
      .populate('property', 'name type')
      .populate('partnershipId', 'tier')
      .lean();

    // Summary statistics
    const summary = {
      totalAmount: commissions.reduce((sum, c) => sum + (c.commission?.calculatedAmount || 0), 0),
      paidAmount: commissions.filter(c => c.status === 'paid').reduce((sum, c) => sum + (c.commission?.calculatedAmount || 0), 0),
      pendingAmount: commissions.filter(c => c.status === 'pending').reduce((sum, c) => sum + (c.commission?.calculatedAmount || 0), 0),
      approvedAmount: commissions.filter(c => c.status === 'approved').reduce((sum, c) => sum + (c.commission?.calculatedAmount || 0), 0),
      cancelledAmount: commissions.filter(c => c.status === 'cancelled').reduce((sum, c) => sum + (c.commission?.calculatedAmount || 0), 0),
      totalCount: commissions.length,
      paidCount: commissions.filter(c => c.status === 'paid').length,
      pendingCount: commissions.filter(c => c.status === 'pending').length,
      approvedCount: commissions.filter(c => c.status === 'approved').length,
      cancelledCount: commissions.filter(c => c.status === 'cancelled').length
    };

    // By status
    const byStatus = [
      { status: 'pending', count: summary.pendingCount, amount: summary.pendingAmount },
      { status: 'approved', count: summary.approvedCount, amount: summary.approvedAmount },
      { status: 'paid', count: summary.paidCount, amount: summary.paidAmount },
      { status: 'cancelled', count: summary.cancelledCount, amount: summary.cancelledAmount }
    ];

    // By tier
    const tierMap = {};
    commissions.forEach(c => {
      const tier = c.partnershipId?.tier || c.partner?.partnerProfile?.tier || 'bronze';
      if (!tierMap[tier]) {
        tierMap[tier] = { count: 0, amount: 0, paidAmount: 0 };
      }
      tierMap[tier].count++;
      tierMap[tier].amount += c.commission?.calculatedAmount || 0;
      if (c.status === 'paid') {
        tierMap[tier].paidAmount += c.commission?.calculatedAmount || 0;
      }
    });
    const byTier = Object.entries(tierMap).map(([tier, data]) => ({
      tier,
      count: data.count,
      amount: data.amount,
      paidAmount: data.paidAmount
    }));

    // By partner (top 20)
    const partnerMap = {};
    commissions.forEach(c => {
      const partnerId = c.partner?._id?.toString();
      if (!partnerId) return;

      if (!partnerMap[partnerId]) {
        partnerMap[partnerId] = {
          partnerId,
          partnerName: `${c.partner?.firstName || ''} ${c.partner?.lastName || ''}`.trim(),
          tier: c.partnershipId?.tier || c.partner?.partnerProfile?.tier || 'bronze',
          totalCommissions: 0,
          paidCommissions: 0,
          pendingCommissions: 0,
          commissionCount: 0
        };
      }
      partnerMap[partnerId].totalCommissions += c.commission?.calculatedAmount || 0;
      partnerMap[partnerId].commissionCount++;
      if (c.status === 'paid') {
        partnerMap[partnerId].paidCommissions += c.commission?.calculatedAmount || 0;
      }
      if (c.status === 'pending' || c.status === 'approved') {
        partnerMap[partnerId].pendingCommissions += c.commission?.calculatedAmount || 0;
      }
    });
    const byPartner = Object.values(partnerMap)
      .sort((a, b) => b.totalCommissions - a.totalCommissions)
      .slice(0, 20);

    // By period (month or week)
    const periodMap = {};
    commissions.forEach(c => {
      if (!c.createdAt) return;

      const date = new Date(c.createdAt);
      let periodKey;

      if (groupBy === 'week') {
        const weekStart = new Date(date);
        weekStart.setDate(date.getDate() - date.getDay());
        periodKey = weekStart.toISOString().split('T')[0];
      } else {
        // Group by month
        periodKey = `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, '0')}`;
      }

      if (!periodMap[periodKey]) {
        periodMap[periodKey] = {
          period: periodKey,
          count: 0,
          amount: 0,
          paidAmount: 0
        };
      }
      periodMap[periodKey].count++;
      periodMap[periodKey].amount += c.commission?.calculatedAmount || 0;
      if (c.status === 'paid') {
        periodMap[periodKey].paidAmount += c.commission?.calculatedAmount || 0;
      }
    });
    const byPeriod = Object.values(periodMap).sort((a, b) => a.period.localeCompare(b.period));

    res.status(200).json({
      success: true,
      data: {
        summary,
        byStatus,
        byTier,
        byPartner,
        byPeriod
      }
    });
  } catch (error) {
    next(error);
  }
};