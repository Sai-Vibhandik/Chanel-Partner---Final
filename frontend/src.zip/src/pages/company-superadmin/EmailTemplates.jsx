import { useState, useEffect } from 'react';
import DashboardLayout from '../../components/layout/DashboardLayout';
import { sidebarConfig } from '../../config/sidebar';
import { useAuth } from '../../context/AuthContext';
import api from '../../utils/api';

const EmailTemplates = () => {
  const { user } = useAuth();
  const config = sidebarConfig.company_superadmin;

  const [templates, setTemplates] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [success, setSuccess] = useState('');

  const [showModal, setShowModal] = useState(false);
  const [editingTemplate, setEditingTemplate] = useState(null);
  const [previewHtml, setPreviewHtml] = useState('');
  const [showPreview, setShowPreview] = useState(false);

  const [formData, setFormData] = useState({
    name: '',
    slug: '',
    subject: '',
    header: {
      showLogo: true,
      logoUrl: '',
      logoWidth: 150,
      backgroundColor: '#4F46E5',
      textColor: '#FFFFFF'
    },
    body: {
      preHeader: '',
      greeting: 'Hello {{userName}},',
      content: '',
      callToAction: {
        text: '',
        url: '',
        buttonColor: '#4F46E5'
      },
      secondaryContent: ''
    },
    footer: {
      showUnsubscribe: true,
      showCompanyAddress: true,
      customFooterText: ''
    },
    styling: {
      primaryColor: '#4F46E5',
      backgroundColor: '#F9FAFB'
    }
  });

  const templateTypes = [
    { slug: 'verification', name: 'Email Verification' },
    { slug: 'password_reset', name: 'Password Reset' },
    { slug: 'welcome', name: 'Welcome Email' },
    { slug: 'property_notification', name: 'Property Notification' },
    { slug: 'partnership_approved', name: 'Partnership Approved' },
    { slug: 'visit_scheduled', name: 'Visit Scheduled' },
    { slug: 'commission_approved', name: 'Commission Approved' },
    { slug: 'custom', name: 'Custom Template' }
  ];

  useEffect(() => {
    fetchTemplates();
  }, []);

  const fetchTemplates = async () => {
    try {
      setLoading(true);
      const response = await api.get('/email/templates');
      setTemplates(response.data.data.templates || []);
    } catch (err) {
      setError(err.response?.data?.message || 'Failed to load templates');
    } finally {
      setLoading(false);
    }
  };

  const handleOpenModal = (template = null) => {
    if (template) {
      setEditingTemplate(template);
      setFormData({
        name: template.name,
        slug: template.slug,
        subject: template.subject,
        header: template.header || formData.header,
        body: template.body || formData.body,
        footer: template.footer || formData.footer,
        styling: template.styling || formData.styling
      });
    } else {
      setEditingTemplate(null);
      setFormData({
        name: '',
        slug: '',
        subject: '',
        header: {
          showLogo: true,
          logoUrl: '',
          logoWidth: 150,
          backgroundColor: '#4F46E5',
          textColor: '#FFFFFF'
        },
        body: {
          preHeader: '',
          greeting: 'Hello {{userName}},',
          content: '',
          callToAction: {
            text: '',
            url: '',
            buttonColor: '#4F46E5'
          },
          secondaryContent: ''
        },
        footer: {
          showUnsubscribe: true,
          showCompanyAddress: true,
          customFooterText: ''
        },
        styling: {
          primaryColor: '#4F46E5',
          backgroundColor: '#F9FAFB'
        }
      });
    }
    setShowModal(true);
  };

  const handleCloseModal = () => {
    setShowModal(false);
    setEditingTemplate(null);
    setPreviewHtml('');
    setShowPreview(false);
  };

  const handleChange = (e) => {
    const { name, value, type, checked } = e.target;
    const newValue = type === 'checkbox' ? checked : value;

    if (name.includes('.')) {
      const keys = name.split('.');
      setFormData(prev => {
        const updated = { ...prev };
        let current = updated;
        for (let i = 0; i < keys.length - 1; i++) {
          current[keys[i]] = { ...current[keys[i]] };
          current = current[keys[i]];
        }
        current[keys[keys.length - 1]] = newValue;
        return updated;
      });
    } else {
      setFormData(prev => ({ ...prev, [name]: newValue }));
    }
  };

  const handlePreview = async () => {
    try {
      const templateId = editingTemplate?._id;
      if (!templateId) return;

      const response = await api.post(`/email/templates/${templateId}/preview`, {
        sampleData: {
          userName: 'John Doe',
          companyName: 'Your Company',
          verificationLink: 'https://example.com/verify',
          resetLink: 'https://example.com/reset'
        }
      });

      setPreviewHtml(response.data.data.html);
      setShowPreview(true);
    } catch (err) {
      setError('Failed to generate preview');
    }
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError('');
    setSuccess('');

    try {
      if (editingTemplate) {
        await api.put(`/email/templates/${editingTemplate._id}`, formData);
        setSuccess('Template updated successfully');
      } else {
        await api.post('/email/templates', formData);
        setSuccess('Template created successfully');
      }
      fetchTemplates();
      handleCloseModal();
    } catch (err) {
      setError(err.response?.data?.message || 'Failed to save template');
    }
  };

  const handleDuplicate = async (template) => {
    try {
      const response = await api.post(`/email/templates/${template._id}/duplicate`);
      const customTemplate = response.data.data.template;

      if (response.data.isExisting) {
        // Existing template found - show message and open for editing
        setSuccess(response.data.message || 'Opening your existing custom template');
      } else {
        setSuccess('Custom template created! You can now edit it.');
      }

      // Open the template in edit mode
      handleOpenModal(customTemplate);
      fetchTemplates();
    } catch (err) {
      setError(err.response?.data?.message || 'Failed to customize template');
    }
  };

  const handleDelete = async (template) => {
    if (!window.confirm('Are you sure you want to delete this template?')) return;

    try {
      await api.delete(`/email/templates/${template._id}`);
      setSuccess('Template deleted successfully');
      fetchTemplates();
    } catch (err) {
      setError(err.response?.data?.message || 'Failed to delete template');
    }
  };

  const getTemplateTypeName = (slug) => {
    const type = templateTypes.find(t => t.slug === slug);
    return type?.name || slug;
  };

  return (
    <DashboardLayout sidebarLinks={config.links} title="Email Templates" subtitle="Manage custom email templates" color={config.color}>
      {/* Messages */}
      {error && (
        <div className="mb-4 p-4 bg-red-50 border border-red-200 rounded-lg text-red-700 flex justify-between items-center">
          <span>{error}</span>
          <button onClick={() => setError('')} className="text-red-700 hover:text-red-900">
            <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
            </svg>
          </button>
        </div>
      )}
      {success && (
        <div className="mb-4 p-4 bg-green-50 border border-green-200 rounded-lg text-green-700 flex justify-between items-center">
          <span>{success}</span>
          <button onClick={() => setSuccess('')} className="text-green-700 hover:text-green-900">
            <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
            </svg>
          </button>
        </div>
      )}

      {/* Header */}
      <div className="flex justify-between items-center mb-6">
        <div>
          <h3 className="text-lg font-medium text-gray-900">Email Templates</h3>
          <p className="text-sm text-gray-500">Customize email templates for your company</p>
        </div>
        <button
          onClick={() => handleOpenModal()}
          className="px-4 py-2 bg-indigo-600 text-white rounded-lg hover:bg-indigo-700 flex items-center gap-2"
        >
          <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 4v16m8-8H4" />
          </svg>
          Create Template
        </button>
      </div>

      {/* Templates Grid */}
      {loading ? (
        <div className="flex items-center justify-center min-h-64">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-indigo-600"></div>
        </div>
      ) : templates.length === 0 ? (
        <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-8 text-center">
          <svg className="w-16 h-16 mx-auto text-gray-300 mb-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 8l7.89 5.26a2 2 0 002.22 0L21 8M5 19h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z" />
          </svg>
          <p className="text-gray-500 mb-2">No custom templates yet</p>
          <p className="text-sm text-gray-400 mb-4">System default templates will be used for emails</p>
          <button
            onClick={() => handleOpenModal()}
            className="px-4 py-2 bg-indigo-600 text-white rounded-lg hover:bg-indigo-700"
          >
            Create Your First Template
          </button>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {templates.map((template) => (
            <div
              key={template._id}
              className={`bg-white rounded-xl shadow-sm border overflow-hidden ${template.isDefault ? 'border-indigo-200' : 'border-gray-100'}`}
            >
              <div className="p-6">
                <div className="flex items-start justify-between mb-4">
                  <div>
                    <h3 className="font-semibold text-gray-900">{template.name}</h3>
                    <p className="text-sm text-gray-500">{getTemplateTypeName(template.slug)}</p>
                  </div>
                  {template.isDefault && (
                    <span className="px-2 py-1 text-xs font-medium bg-indigo-100 text-indigo-800 rounded-full">
                      Default
                    </span>
                  )}
                </div>

                <p className="text-sm text-gray-600 mb-4 line-clamp-2">{template.subject}</p>

                <div className="flex items-center gap-2 mb-4">
                  {template.header?.showLogo && (
                    <span className="px-2 py-1 text-xs bg-blue-50 text-blue-700 rounded">Logo</span>
                  )}
                  {template.body?.callToAction?.text && (
                    <span className="px-2 py-1 text-xs bg-green-50 text-green-700 rounded">CTA</span>
                  )}
                </div>

                <div className="flex items-center justify-between">
                  <span className={`text-xs ${template.isActive ? 'text-green-600' : 'text-gray-400'}`}>
                    {template.isActive ? 'Active' : 'Inactive'}
                  </span>

                  <div className="flex items-center gap-2">
                    {!template.isDefault && (
                      <>
                        <button
                          onClick={() => handleOpenModal(template)}
                          className="p-1 text-gray-400 hover:text-indigo-600"
                          title="Edit"
                        >
                          <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M11 5H6a2 2 0 00-2 2v11a2 2 0 002 2h11a2 2 0 002-2v-5m-1.414-9.414a2 2 0 112.828 2.828L11.828 15H9v-2.828l8.586-8.586z" />
                          </svg>
                        </button>
                        <button
                          onClick={() => handleDuplicate(template)}
                          className="p-1 text-gray-400 hover:text-indigo-600"
                          title="Duplicate"
                        >
                          <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8 16H6a2 2 0 01-2-2V6a2 2 0 012-2h8a2 2 0 012 2v2m-6 12h8a2 2 0 002-2v-8a2 2 0 00-2-2h-8a2 2 0 00-2 2v8a2 2 0 002 2z" />
                          </svg>
                        </button>
                        <button
                          onClick={() => handleDelete(template)}
                          className="p-1 text-gray-400 hover:text-red-600"
                          title="Delete"
                        >
                          <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16" />
                          </svg>
                        </button>
                      </>
                    )}
                    {template.isDefault && (
                      <button
                        onClick={() => handleDuplicate(template)}
                        className="px-3 py-1 text-sm text-indigo-600 hover:text-indigo-800"
                      >
                        Customize
                      </button>
                    )}
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}

      {/* Template Modal */}
      {showModal && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4 overflow-y-auto">
          <div className="bg-white rounded-xl max-w-4xl w-full my-8">
            <div className="px-6 py-4 border-b border-gray-200 flex justify-between items-center sticky top-0 bg-white">
              <h3 className="text-lg font-semibold">
                {editingTemplate ? 'Edit Template' : 'Create Template'}
              </h3>
              <button onClick={handleCloseModal} className="text-gray-400 hover:text-gray-600">
                <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
                </svg>
              </button>
            </div>

            <form onSubmit={handleSubmit} className="p-6 space-y-6">
              {/* Basic Info */}
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Template Name</label>
                  <input
                    type="text"
                    name="name"
                    value={formData.name}
                    onChange={handleChange}
                    className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500"
                    required
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Template Type</label>
                  <select
                    name="slug"
                    value={formData.slug}
                    onChange={handleChange}
                    className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500"
                    required
                    disabled={editingTemplate}
                  >
                    <option value="">Select type...</option>
                    {templateTypes.map(type => (
                      <option key={type.slug} value={type.slug}>{type.name}</option>
                    ))}
                  </select>
                </div>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Subject Line</label>
                <input
                  type="text"
                  name="subject"
                  value={formData.subject}
                  onChange={handleChange}
                  placeholder="e.g., Welcome to {{companyName}}!"
                  className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500"
                  required
                />
                <p className="text-xs text-gray-500 mt-1">Use {{variable}} for dynamic content</p>
              </div>

              {/* Header Settings */}
              <div className="border-t pt-4">
                <h4 className="font-medium text-gray-900 mb-3">Header Settings</h4>
                <div className="grid grid-cols-3 gap-4">
                  <div className="flex items-center">
                    <input
                      type="checkbox"
                      name="header.showLogo"
                      checked={formData.header.showLogo}
                      onChange={handleChange}
                      className="mr-2"
                    />
                    <label className="text-sm text-gray-700">Show Logo</label>
                  </div>
                  <div>
                    <label className="block text-xs text-gray-600 mb-1">Logo URL (Optional)</label>
                    <input
                      type="text"
                      name="header.logoUrl"
                      value={formData.header.logoUrl}
                      onChange={handleChange}
                      placeholder="Leave empty for company logo"
                      className="w-full px-3 py-1.5 text-sm border border-gray-300 rounded"
                    />
                  </div>
                  <div>
                    <label className="block text-xs text-gray-600 mb-1">Header Background</label>
                    <input
                      type="color"
                      name="header.backgroundColor"
                      value={formData.header.backgroundColor}
                      onChange={handleChange}
                      className="w-full h-8 border border-gray-300 rounded cursor-pointer"
                    />
                  </div>
                </div>
              </div>

              {/* Body Content */}
              <div className="border-t pt-4">
                <h4 className="font-medium text-gray-900 mb-3">Email Content</h4>
                <div className="space-y-4">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">Greeting</label>
                    <input
                      type="text"
                      name="body.greeting"
                      value={formData.body.greeting}
                      onChange={handleChange}
                      className="w-full px-4 py-2 border border-gray-300 rounded-lg"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">Main Content</label>
                    <textarea
                      name="body.content"
                      value={formData.body.content}
                      onChange={handleChange}
                      rows={5}
                      className="w-full px-4 py-2 border border-gray-300 rounded-lg"
                      required
                    />
                  </div>
                </div>
              </div>

              {/* CTA Button */}
              <div className="border-t pt-4">
                <h4 className="font-medium text-gray-900 mb-3">Call-to-Action Button (Optional)</h4>
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">Button Text</label>
                    <input
                      type="text"
                      name="body.callToAction.text"
                      value={formData.body.callToAction.text}
                      onChange={handleChange}
                      placeholder="e.g., View Details"
                      className="w-full px-4 py-2 border border-gray-300 rounded-lg"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">Button URL</label>
                    <input
                      type="text"
                      name="body.callToAction.url"
                      value={formData.body.callToAction.url}
                      onChange={handleChange}
                      placeholder="e.g., {{dashboardUrl}}"
                      className="w-full px-4 py-2 border border-gray-300 rounded-lg"
                    />
                  </div>
                </div>
              </div>

              {/* Footer */}
              <div className="border-t pt-4">
                <h4 className="font-medium text-gray-900 mb-3">Footer Settings</h4>
                <div className="flex gap-6">
                  <label className="flex items-center">
                    <input
                      type="checkbox"
                      name="footer.showUnsubscribe"
                      checked={formData.footer.showUnsubscribe}
                      onChange={handleChange}
                      className="mr-2"
                    />
                    <span className="text-sm text-gray-700">Show Unsubscribe Link</span>
                  </label>
                  <label className="flex items-center">
                    <input
                      type="checkbox"
                      name="footer.showCompanyAddress"
                      checked={formData.footer.showCompanyAddress}
                      onChange={handleChange}
                      className="mr-2"
                    />
                    <span className="text-sm text-gray-700">Show Company Address</span>
                  </label>
                </div>
              </div>

              {/* Submit */}
              <div className="border-t pt-4 flex justify-end gap-3">
                <button
                  type="button"
                  onClick={handleCloseModal}
                  className="px-4 py-2 border border-gray-300 rounded-lg hover:bg-gray-50"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 bg-indigo-600 text-white rounded-lg hover:bg-indigo-700"
                >
                  {editingTemplate ? 'Update Template' : 'Create Template'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Preview Modal */}
      {showPreview && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-xl max-w-3xl w-full max-h-[80vh] overflow-hidden">
            <div className="px-6 py-4 border-b border-gray-200 flex justify-between items-center">
              <h3 className="text-lg font-semibold">Email Preview</h3>
              <button onClick={() => setShowPreview(false)} className="text-gray-400 hover:text-gray-600">
                <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
                </svg>
              </button>
            </div>
            <div className="p-6 overflow-auto max-h-[60vh]">
              <iframe
                srcDoc={previewHtml}
                title="Email Preview"
                className="w-full border border-gray-200 rounded"
                style={{ height: '500px' }}
              />
            </div>
          </div>
        </div>
      )}
    </DashboardLayout>
  );
};

export default EmailTemplates;