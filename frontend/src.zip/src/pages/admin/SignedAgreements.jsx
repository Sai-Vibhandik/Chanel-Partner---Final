import { useState, useEffect } from 'react';
import DashboardLayout from '../../components/layout/DashboardLayout';
import { sidebarConfig } from '../../config/sidebar';
import { useAuth } from '../../context/AuthContext';
import api from '../../utils/api';

const SignedAgreements = () => {
  const { user } = useAuth();
  const config = sidebarConfig[user?.role] || sidebarConfig.company_superadmin;

  const [partners, setPartners] = useState([]);
  const [templates, setTemplates] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [search, setSearch] = useState('');
  const [page, setPage] = useState(1);
  const [totalPages, setTotalPages] = useState(1);

  // Selected partner for detail view
  const [selectedPartner, setSelectedPartner] = useState(null);

  // Selected signature for viewing
  const [viewingSignature, setViewingSignature] = useState(null);
  const [signatureContent, setSignatureContent] = useState('');
  const [loadingContent, setLoadingContent] = useState(false);

  useEffect(() => {
    fetchPartners();
  }, [page]);

  const fetchPartners = async () => {
    try {
      setLoading(true);
      setError('');

      const params = new URLSearchParams();
      if (search) params.append('search', search);
      params.append('page', page);
      params.append('limit', 10);

      const response = await api.get(`/agreements/signatures/partners?${params.toString()}`);
      setPartners(response.data.data.partners);
      setTemplates(response.data.data.templates);
      setTotalPages(response.data.data.pagination.pages);
    } catch (err) {
      setError(err.response?.data?.message || 'Failed to load signed agreements');
    } finally {
      setLoading(false);
    }
  };

  const fetchSignatureContent = async (signature) => {
    try {
      setLoadingContent(true);
      setViewingSignature(signature);

      // Fetch the agreement template content
      const response = await api.get(`/agreements/${signature.agreementTemplateId._id}`);
      const template = response.data.data.template;

      // Replace placeholders with actual values
      let content = template.content || '';
      content = content
        .replace(/{{partnerName}}/g, signature.typedName || '_________________')
        .replace(/{{companyName}}/g, selectedPartner?.partner?.company?.name || '_________________')
        .replace(/{{date}}/g, new Date(signature.signedAt).toLocaleDateString())
        .replace(/{{partnerPhone}}/g, selectedPartner?.partner?.phone || '_________________')
        .replace(/{{partnerEmail}}/g, selectedPartner?.partner?.email || '_________________');

      setSignatureContent(content);
    } catch (err) {
      setError('Failed to load agreement content');
    } finally {
      setLoadingContent(false);
    }
  };

  const handleSearch = (e) => {
    e.preventDefault();
    setPage(1);
    fetchPartners();
  };

  const formatDate = (date) => {
    if (!date) return '-';
    return new Date(date).toLocaleDateString('en-US', {
      year: 'numeric',
      month: 'short',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    });
  };

  const getStatusColor = (partner) => {
    if (partner.allSigned) return 'bg-green-100 text-green-800';
    if (partner.hasOutdated) return 'bg-yellow-100 text-yellow-800';
    if (partner.signedRequired > 0) return 'bg-blue-100 text-blue-800';
    return 'bg-gray-100 text-gray-800';
  };

  const getStatusText = (partner) => {
    if (partner.allSigned) return 'All Signed';
    if (partner.hasOutdated) return 'Update Needed';
    if (partner.signedRequired > 0) return 'In Progress';
    return 'Not Started';
  };

  const getTypeLabel = (type) => {
    const types = {
      nda: 'NDA',
      nca: 'Non-Compete',
      cpa: 'Channel Partner Agreement',
      code_of_conduct: 'Code of Conduct',
      gdpr_consent: 'GDPR Consent',
      other: 'Other'
    };
    return types[type] || type;
  };

  return (
    <DashboardLayout
      sidebarLinks={config.links}
      title="Signed Agreements"
      subtitle="View partner signed agreements and history"
      color={config.color}
    >
      {/* Error */}
      {error && (
        <div className="mb-6 p-4 bg-red-50 border border-red-200 rounded-lg text-red-700">
          {error}
        </div>
      )}

      {/* Search */}
      <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-4 mb-6">
        <form onSubmit={handleSearch} className="flex gap-4">
          <input
            type="text"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="Search by partner name or email..."
            className="flex-1 px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500"
          />
          <button
            type="submit"
            className="px-6 py-2 bg-indigo-600 text-white rounded-lg hover:bg-indigo-700"
          >
            Search
          </button>
        </form>
      </div>

      {/* Partners List */}
      {loading ? (
        <div className="text-center py-10">
          <div className="animate-spin rounded-full h-10 w-10 border-b-2 border-indigo-600 mx-auto"></div>
          <p className="mt-4 text-gray-600">Loading partners...</p>
        </div>
      ) : partners.length === 0 ? (
        <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-10 text-center">
          <svg className="w-16 h-16 text-gray-300 mx-auto mb-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" />
          </svg>
          <h3 className="text-lg font-medium text-gray-900 mb-2">No Partners Found</h3>
          <p className="text-gray-500">No partners have signed agreements yet.</p>
        </div>
      ) : (
        <div className="space-y-4">
          {partners.map((partnerData) => (
            <div
              key={partnerData.partnershipId}
              className="bg-white rounded-xl shadow-sm border border-gray-100 overflow-hidden"
            >
              {/* Partner Card Header */}
              <div
                className="p-4 cursor-pointer hover:bg-gray-50 transition-colors"
                onClick={() => setSelectedPartner(selectedPartner?.partnershipId === partnerData.partnershipId ? null : partnerData)}
              >
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-4">
                    <div className="w-12 h-12 rounded-full bg-gradient-to-br from-indigo-500 to-purple-500 flex items-center justify-center text-white font-bold text-lg">
                      {partnerData.partner?.firstName?.charAt(0) || 'P'}
                      {partnerData.partner?.lastName?.charAt(0) || ''}
                    </div>
                    <div>
                      <h3 className="font-semibold text-gray-900">
                        {partnerData.partner?.firstName} {partnerData.partner?.lastName}
                      </h3>
                      <p className="text-sm text-gray-500">{partnerData.partner?.email}</p>
                    </div>
                  </div>

                  <div className="flex items-center gap-4">
                    {/* Progress */}
                    <div className="hidden md:flex items-center gap-3">
                      <div className="w-32 bg-gray-200 rounded-full h-2">
                        <div
                          className={`h-2 rounded-full ${partnerData.allSigned ? 'bg-green-500' : 'bg-indigo-500'}`}
                          style={{ width: `${partnerData.completionPercentage}%` }}
                        />
                      </div>
                      <span className="text-sm text-gray-600">{partnerData.completionPercentage}%</span>
                    </div>

                    {/* Status Badge */}
                    <span className={`px-3 py-1 rounded-full text-xs font-medium ${getStatusColor(partnerData)}`}>
                      {getStatusText(partnerData)}
                    </span>

                    {/* Expand Icon */}
                    <svg
                      className={`w-5 h-5 text-gray-400 transition-transform ${selectedPartner?.partnershipId === partnerData.partnershipId ? 'rotate-180' : ''}`}
                      fill="none"
                      stroke="currentColor"
                      viewBox="0 0 24 24"
                    >
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 9l-7 7-7-7" />
                    </svg>
                  </div>
                </div>

                {/* Quick Stats */}
                <div className="mt-3 flex items-center gap-4 text-sm text-gray-500">
                  <span className="flex items-center gap-1">
                    <span className="w-2 h-2 rounded-full bg-green-500"></span>
                    {partnerData.signedRequired} of {partnerData.requiredTemplates} required signed
                  </span>
                  {partnerData.hasOutdated && (
                    <span className="text-yellow-600">
                      ⚠️ Some agreements need re-signing
                    </span>
                  )}
                  {partnerData.recentSignature && (
                    <span>Last signed: {formatDate(partnerData.recentSignature)}</span>
                  )}
                </div>
              </div>

              {/* Expanded Detail View */}
              {selectedPartner?.partnershipId === partnerData.partnershipId && (
                <div className="border-t border-gray-100 bg-gray-50 p-4">
                  <h4 className="font-medium text-gray-900 mb-3">Agreement History</h4>

                  {/* Required Agreements Status */}
                  <div className="mb-4">
                    <p className="text-sm text-gray-600 mb-2">Required Agreements:</p>
                    <div className="flex flex-wrap gap-2">
                      {templates.map((template) => {
                        const signature = partnerData.signatures.find(
                          s => s.agreementTemplateId?._id?.toString() === template._id.toString() &&
                               s.version === template.version && s.status === 'signed'
                        );
                        const outdatedSig = partnerData.signatures.find(
                          s => s.agreementTemplateId?._id?.toString() === template._id.toString() &&
                               s.version < template.version
                        );

                        return (
                          <span
                            key={template._id}
                            className={`px-3 py-1 rounded-full text-sm ${
                              signature
                                ? 'bg-green-100 text-green-800'
                                : outdatedSig
                                ? 'bg-yellow-100 text-yellow-800'
                                : 'bg-gray-100 text-gray-600'
                            }`}
                          >
                            {signature ? '✓ ' : outdatedSig ? '⚠️ ' : '○ '}
                            {template.name}
                            {outdatedSig && !signature && ` (v${outdatedSig.version} → v${template.version})`}
                          </span>
                        );
                      })}
                    </div>
                  </div>

                  {/* Signatures Table */}
                  {partnerData.signatures.length > 0 ? (
                    <div className="overflow-x-auto bg-white rounded-lg">
                      <table className="min-w-full">
                        <thead className="bg-gray-100">
                          <tr className="text-left text-xs text-gray-500 uppercase">
                            <th className="px-4 py-3">Agreement</th>
                            <th className="px-4 py-3">Version</th>
                            <th className="px-4 py-3">Signed At</th>
                            <th className="px-4 py-3">Signed By</th>
                            <th className="px-4 py-3">IP Address</th>
                            <th className="px-4 py-3">Status</th>
                            <th className="px-4 py-3">Actions</th>
                          </tr>
                        </thead>
                        <tbody className="divide-y divide-gray-200">
                          {partnerData.signatures.map((sig) => {
                            const template = templates.find(t => t._id.toString() === sig.agreementTemplateId?._id?.toString());
                            const isLatest = template && sig.version === template.version && sig.status === 'signed';

                            return (
                              <tr key={sig._id} className="hover:bg-gray-50">
                                <td className="px-4 py-3">
                                  <div className="font-medium text-gray-900">
                                    {sig.agreementTemplateId?.name || 'Unknown'}
                                  </div>
                                  <div className="text-gray-500 text-sm">{getTypeLabel(sig.agreementTemplateId?.type)}</div>
                                </td>
                                <td className="px-4 py-3">
                                  <span className="px-2 py-1 rounded text-xs bg-blue-100 text-blue-800">
                                    v{sig.version}
                                  </span>
                                </td>
                                <td className="px-4 py-3 text-gray-600 text-sm">{formatDate(sig.signedAt)}</td>
                                <td className="px-4 py-3 text-gray-600">{sig.typedName || '-'}</td>
                                <td className="px-4 py-3 text-gray-500 text-xs">{sig.ipAddress || '-'}</td>
                                <td className="px-4 py-3">
                                  <span className={`px-2 py-1 rounded text-xs ${
                                    sig.status === 'signed' && isLatest ? 'bg-green-100 text-green-800' :
                                    sig.status === 'expired' ? 'bg-red-100 text-red-800' :
                                    'bg-yellow-100 text-yellow-800'
                                  }`}>
                                    {sig.status === 'signed' && isLatest ? 'Signed' :
                                     sig.status === 'expired' ? 'Expired' : 'Outdated'}
                                  </span>
                                </td>
                                <td className="px-4 py-3">
                                  <button
                                    onClick={(e) => {
                                      e.stopPropagation();
                                      fetchSignatureContent(sig);
                                    }}
                                    className="text-indigo-600 hover:text-indigo-800 text-sm font-medium"
                                  >
                                    View
                                  </button>
                                </td>
                              </tr>
                            );
                          })}
                        </tbody>
                      </table>
                    </div>
                  ) : (
                    <p className="text-gray-500 text-sm">No agreements signed yet.</p>
                  )}
                </div>
              )}
            </div>
          ))}
        </div>
      )}

      {/* Pagination */}
      {totalPages > 1 && (
        <div className="flex items-center justify-between mt-6">
          <button
            onClick={() => setPage(p => Math.max(1, p - 1))}
            disabled={page === 1}
            className="px-4 py-2 border border-gray-300 rounded-lg disabled:opacity-50 disabled:cursor-not-allowed"
          >
            Previous
          </button>
          <span className="text-gray-600">Page {page} of {totalPages}</span>
          <button
            onClick={() => setPage(p => Math.min(totalPages, p + 1))}
            disabled={page === totalPages}
            className="px-4 py-2 border border-gray-300 rounded-lg disabled:opacity-50 disabled:cursor-not-allowed"
          >
            Next
          </button>
        </div>
      )}

      {/* View Signature Modal */}
      {viewingSignature && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-xl shadow-xl max-w-3xl w-full max-h-[90vh] overflow-hidden flex flex-col">
            <div className="p-6 border-b border-gray-200 flex justify-between items-center">
              <div>
                <h3 className="text-lg font-semibold text-gray-900">Signed Agreement</h3>
                <p className="text-sm text-gray-500">
                  {viewingSignature.agreementTemplateId?.name} - Version {viewingSignature.version}
                </p>
              </div>
              <button
                onClick={() => setViewingSignature(null)}
                className="p-2 text-gray-400 hover:text-gray-600"
              >
                <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
                </svg>
              </button>
            </div>

            <div className="p-6 overflow-y-auto flex-1">
              {/* Signature Details */}
              <div className="grid grid-cols-2 gap-4 mb-6 bg-gray-50 p-4 rounded-lg">
                <div>
                  <p className="text-sm text-gray-500">Signed By</p>
                  <p className="font-medium">{viewingSignature.typedName}</p>
                </div>
                <div>
                  <p className="text-sm text-gray-500">Signed At</p>
                  <p className="font-medium">{formatDate(viewingSignature.signedAt)}</p>
                </div>
                <div>
                  <p className="text-sm text-gray-500">IP Address</p>
                  <p className="font-medium">{viewingSignature.ipAddress || 'Not recorded'}</p>
                </div>
                <div>
                  <p className="text-sm text-gray-500">Status</p>
                  <span className={`px-2 py-1 rounded text-xs ${
                    viewingSignature.status === 'signed' ? 'bg-green-100 text-green-800' : 'bg-red-100 text-red-800'
                  }`}>
                    {viewingSignature.status === 'signed' ? 'Valid' : 'Expired'}
                  </span>
                </div>
              </div>

              {/* Agreement Content */}
              <div className="mb-4">
                <h4 className="font-medium text-gray-900 mb-2">Agreement Content</h4>
                {loadingContent ? (
                  <div className="text-center py-10">
                    <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-indigo-600 mx-auto"></div>
                  </div>
                ) : (
                  <div className="bg-gray-50 border border-gray-200 rounded-lg p-4 max-h-96 overflow-y-auto">
                    <pre className="whitespace-pre-wrap font-mono text-sm text-gray-800">
                      {signatureContent}
                    </pre>
                  </div>
                )}
              </div>

              {/* Signature Block */}
              <div className="border-t border-gray-200 pt-4">
                <h4 className="font-medium text-gray-900 mb-2">Electronic Signature</h4>
                <div className="bg-indigo-50 border border-indigo-200 rounded-lg p-4">
                  <p className="text-sm text-indigo-800 mb-2">
                    <strong>Signed electronically by:</strong> {viewingSignature.typedName}
                  </p>
                  <p className="text-sm text-indigo-700">
                    <strong>Date:</strong> {formatDate(viewingSignature.signedAt)}
                  </p>
                  {viewingSignature.ipAddress && (
                    <p className="text-sm text-indigo-700">
                      <strong>IP Address:</strong> {viewingSignature.ipAddress}
                    </p>
                  )}
                </div>
              </div>
            </div>

            <div className="p-4 border-t border-gray-200 flex justify-end">
              <button
                onClick={() => setViewingSignature(null)}
                className="px-4 py-2 border border-gray-300 rounded-lg hover:bg-gray-50"
              >
                Close
              </button>
            </div>
          </div>
        </div>
      )}
    </DashboardLayout>
  );
};

export default SignedAgreements;