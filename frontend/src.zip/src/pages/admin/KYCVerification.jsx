import { useState, useEffect } from 'react';
import DashboardLayout from '../../components/layout/DashboardLayout';
import { sidebarConfig } from '../../config/sidebar';
import { useAuth } from '../../context/AuthContext';
import api, { getDocumentViewUrl } from '../../utils/api';

const KYCVerification = () => {
  const { user } = useAuth();
  // Use the appropriate sidebar config based on user role
  const config = sidebarConfig[user?.role] || sidebarConfig.company_superadmin;

  const [reviews, setReviews] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [success, setSuccess] = useState('');

  // Filters
  const [statusFilter, setStatusFilter] = useState('pending');
  const [searchQuery, setSearchQuery] = useState('');
  const [page, setPage] = useState(1);
  const [totalPages, setTotalPages] = useState(1);

  // Document view modal
  const [selectedDocument, setSelectedDocument] = useState(null);
  const [showRejectModal, setShowRejectModal] = useState(false);
  const [rejectReason, setRejectReason] = useState('');
  const [selectedPartnership, setSelectedPartnership] = useState(null);
  const [selectedDocId, setSelectedDocId] = useState(null);
  const [processing, setProcessing] = useState(false);

  useEffect(() => {
    fetchKYCReviews();
  }, [statusFilter, page]);

  const fetchKYCReviews = async () => {
    try {
      setLoading(true);
      setError('');

      const params = new URLSearchParams();
      if (statusFilter) params.append('status', statusFilter);
      if (searchQuery) params.append('search', searchQuery);
      params.append('page', page);
      params.append('limit', 10);

      const response = await api.get(`/partner-company/kyc-reviews?${params.toString()}`);
      setReviews(response.data.data.reviews);
      setTotalPages(response.data.data.pagination.pages);
    } catch (err) {
      setError(err.response?.data?.message || 'Failed to load KYC reviews');
    } finally {
      setLoading(false);
    }
  };

  const handleSearch = (e) => {
    e.preventDefault();
    setPage(1);
    fetchKYCReviews();
  };

  const handleVerifyDocument = async (partnershipId, documentId) => {
    try {
      setProcessing(true);
      setError('');

      await api.put(`/partner-company/${partnershipId}/kyc/${documentId}/verify`, {
        status: 'verified'
      });

      setSuccess('Document verified successfully');
      fetchKYCReviews();
    } catch (err) {
      setError(err.response?.data?.message || 'Failed to verify document');
    } finally {
      setProcessing(false);
    }
  };

  const handleRejectDocument = async () => {
    if (!rejectReason.trim()) {
      setError('Please provide a rejection reason');
      return;
    }

    try {
      setProcessing(true);
      setError('');

      await api.put(`/partner-company/${selectedPartnership}/kyc/${selectedDocId}/verify`, {
        status: 'rejected',
        reason: rejectReason.trim()
      });

      setSuccess('Document rejected');
      setShowRejectModal(false);
      setRejectReason('');
      setSelectedPartnership(null);
      setSelectedDocId(null);
      fetchKYCReviews();
    } catch (err) {
      setError(err.response?.data?.message || 'Failed to reject document');
    } finally {
      setProcessing(false);
    }
  };

  const openRejectModal = (partnershipId, documentId) => {
    setSelectedPartnership(partnershipId);
    setSelectedDocId(documentId);
    setShowRejectModal(true);
    setRejectReason('');
  };

  const getStatusBadge = (status) => {
    const styles = {
      verified: 'bg-green-100 text-green-800',
      pending: 'bg-yellow-100 text-yellow-800',
      rejected: 'bg-red-100 text-red-800',
      not_uploaded: 'bg-gray-100 text-gray-800'
    };
    const labels = {
      verified: 'Verified',
      pending: 'Pending',
      rejected: 'Rejected',
      not_uploaded: 'Not Uploaded'
    };
    return (
      <span className={`px-2 py-1 rounded-full text-xs font-medium ${styles[status] || 'bg-gray-100 text-gray-800'}`}>
        {labels[status] || status}
      </span>
    );
  };

  const getKYCStatusBadge = (status, completion) => {
    if (status === 'verified') {
      return <span className="px-3 py-1 rounded-full text-sm font-medium bg-green-100 text-green-800">KYC Verified</span>;
    }
    if (completion === 0) {
      return <span className="px-3 py-1 rounded-full text-sm font-medium bg-gray-100 text-gray-800">Not Started</span>;
    }
    return <span className="px-3 py-1 rounded-full text-sm font-medium bg-yellow-100 text-yellow-800">In Progress ({completion}%)</span>;
  };

  const formatDate = (date) => {
    if (!date) return '-';
    return new Date(date).toLocaleDateString('en-US', {
      year: 'numeric',
      month: 'short',
      day: 'numeric'
    });
  };

  return (
    <DashboardLayout
      sidebarLinks={config.links}
      title="KYC Verification"
      subtitle="Review and verify partner documents"
      color={config.color}
    >
      {/* Error/Success Messages */}
      {error && (
        <div className="mb-6 p-4 bg-red-50 border border-red-200 rounded-lg text-red-700">{error}</div>
      )}
      {success && (
        <div className="mb-6 p-4 bg-green-50 border border-green-200 rounded-lg text-green-700">{success}</div>
      )}

      {/* Filters */}
      <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-4 mb-6">
        <div className="flex flex-col md:flex-row gap-4">
          <div className="flex-1">
            <form onSubmit={handleSearch} className="flex gap-2">
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="Search by name or email..."
                className="flex-1 px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500"
              />
              <button
                type="submit"
                className="px-4 py-2 bg-indigo-600 text-white rounded-lg hover:bg-indigo-700"
              >
                Search
              </button>
            </form>
          </div>
          <div>
            <select
              value={statusFilter}
              onChange={(e) => { setStatusFilter(e.target.value); setPage(1); }}
              className="px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500"
            >
              <option value="">All Status</option>
              <option value="pending">Pending Review</option>
              <option value="verified">Fully Verified</option>
              <option value="rejected">Has Rejected</option>
            </select>
          </div>
        </div>
      </div>

      {/* KYC Reviews List */}
      {loading ? (
        <div className="text-center py-10">
          <div className="animate-spin rounded-full h-10 w-10 border-b-2 border-indigo-600 mx-auto"></div>
          <p className="mt-4 text-gray-600">Loading KYC reviews...</p>
        </div>
      ) : reviews.length === 0 ? (
        <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-10 text-center">
          <svg className="w-16 h-16 text-gray-300 mx-auto mb-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" />
          </svg>
          <h3 className="text-lg font-medium text-gray-900 mb-2">No KYC Reviews</h3>
          <p className="text-gray-500">
            {statusFilter === 'pending' ? 'All documents are verified!' : 'No partners found with this status.'}
          </p>
        </div>
      ) : (
        <div className="space-y-4">
          {reviews.map((review) => (
            <div key={review.partnershipId} className="bg-white rounded-xl shadow-sm border border-gray-100 overflow-hidden">
              {/* Partner Header */}
              <div className="p-4 border-b border-gray-100 flex flex-col md:flex-row md:items-center justify-between gap-4">
                <div className="flex items-center gap-4">
                  <div className="w-12 h-12 rounded-full bg-gradient-to-br from-indigo-500 to-purple-500 flex items-center justify-center text-white font-bold text-lg">
                    {review.partner?.firstName?.charAt(0) || 'P'}
                  </div>
                  <div>
                    <h3 className="font-semibold text-gray-900">
                      {review.partner?.firstName} {review.partner?.lastName}
                    </h3>
                    <p className="text-sm text-gray-500">{review.partner?.email}</p>
                  </div>
                </div>
                <div className="flex items-center gap-3">
                  {getKYCStatusBadge(review.kycStatus, review.completionPercentage)}
                  <span className={`px-3 py-1 rounded-full text-sm font-medium ${
                    review.partnershipStatus === 'active' ? 'bg-green-100 text-green-800' :
                    review.partnershipStatus === 'pending' ? 'bg-yellow-100 text-yellow-800' :
                    'bg-red-100 text-red-800'
                  }`}>
                    {review.partnershipStatus}
                  </span>
                </div>
              </div>

              {/* Progress Bar */}
              <div className="px-4 py-3 bg-gray-50">
                <div className="flex items-center justify-between mb-2">
                  <span className="text-sm text-gray-600">Verification Progress</span>
                  <span className="text-sm font-medium text-gray-900">{review.completionPercentage}%</span>
                </div>
                <div className="w-full bg-gray-200 rounded-full h-2">
                  <div
                    className={`h-2 rounded-full ${review.completionPercentage === 100 ? 'bg-green-500' : 'bg-yellow-500'}`}
                    style={{ width: `${review.completionPercentage}%` }}
                  />
                </div>
                <div className="flex items-center gap-4 mt-2 text-xs text-gray-500">
                  <span className="flex items-center gap-1">
                    <span className="w-2 h-2 rounded-full bg-green-500"></span>
                    {review.statusCounts.verified} verified
                  </span>
                  <span className="flex items-center gap-1">
                    <span className="w-2 h-2 rounded-full bg-yellow-500"></span>
                    {review.statusCounts.pending} pending
                  </span>
                  <span className="flex items-center gap-1">
                    <span className="w-2 h-2 rounded-full bg-red-500"></span>
                    {review.statusCounts.rejected} rejected
                  </span>
                  <span className="flex items-center gap-1">
                    <span className="w-2 h-2 rounded-full bg-gray-300"></span>
                    {review.statusCounts.notUploaded} not uploaded
                  </span>
                </div>
              </div>

              {/* Documents Table */}
              <div className="p-4">
                <h4 className="font-medium text-gray-900 mb-3">Documents</h4>
                <div className="overflow-x-auto">
                  <table className="min-w-full">
                    <thead>
                      <tr className="text-left text-xs text-gray-500 uppercase tracking-wider">
                        <th className="pb-2">Document</th>
                        <th className="pb-2">Region</th>
                        <th className="pb-2">Status</th>
                        <th className="pb-2">Uploaded</th>
                        <th className="pb-2">Verified By</th>
                        <th className="pb-2 text-right">Actions</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-gray-100">
                      {review.documents.map((doc) => (
                        <tr key={doc.type} className="text-sm">
                          <td className="py-3">
                            <div className="flex items-center gap-2">
                              <span className="font-medium text-gray-900">{doc.name}</span>
                              {doc.required && <span className="text-red-500">*</span>}
                            </div>
                          </td>
                          <td className="py-3">
                            <span className={`px-2 py-0.5 rounded text-xs ${
                              doc.region === 'india' ? 'bg-orange-100 text-orange-800' : 'bg-blue-100 text-blue-800'
                            }`}>
                              {doc.region === 'india' ? '🇮🇳 India' : '🇦🇪 Dubai'}
                            </span>
                          </td>
                          <td className="py-3">{getStatusBadge(doc.status)}</td>
                          <td className="py-3 text-gray-600">
                            {doc.uploadedAt ? formatDate(doc.uploadedAt) : '-'}
                          </td>
                          <td className="py-3 text-gray-600">
                            {doc.status === 'verified' && doc.verifiedBy ? 'Verified' : '-'}
                          </td>
                          <td className="py-3 text-right">
                            {doc.status === 'not_uploaded' ? (
                              <span className="text-gray-400 text-xs">Not uploaded</span>
                            ) : (
                              <div className="flex items-center justify-end gap-2">
                                {doc.url && (
                                  <button
                                    onClick={() => setSelectedDocument(doc)}
                                    className="text-indigo-600 hover:text-indigo-800 text-sm"
                                  >
                                    View
                                  </button>
                                )}
                                {doc.status === 'pending' && (
                                  <>
                                    <button
                                      onClick={() => handleVerifyDocument(review.partnershipId, doc.documentId)}
                                      disabled={processing}
                                      className="text-green-600 hover:text-green-800 text-sm disabled:opacity-50"
                                    >
                                      Verify
                                    </button>
                                    <button
                                      onClick={() => openRejectModal(review.partnershipId, doc.documentId)}
                                      className="text-red-600 hover:text-red-800 text-sm"
                                    >
                                      Reject
                                    </button>
                                  </>
                                )}
                                {doc.status === 'rejected' && doc.rejectionReason && (
                                  <span className="text-red-600 text-xs" title={doc.rejectionReason}>
                                    Reason: {doc.rejectionReason.substring(0, 30)}...
                                  </span>
                                )}
                              </div>
                            )}
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}

      {/* Pagination */}
      {totalPages > 1 && (
        <div className="flex items-center justify-between mt-6">
          <button
            onClick={() => setPage(p => Math.max(1, p - 1))}
            disabled={page === 1}
            className="px-4 py-2 border border-gray-300 rounded-lg disabled:opacity-50 disabled:cursor-not-allowed"
          >
            Previous
          </button>
          <span className="text-gray-600">Page {page} of {totalPages}</span>
          <button
            onClick={() => setPage(p => Math.min(totalPages, p + 1))}
            disabled={page === totalPages}
            className="px-4 py-2 border border-gray-300 rounded-lg disabled:opacity-50 disabled:cursor-not-allowed"
          >
            Next
          </button>
        </div>
      )}

      {/* Document View Modal */}
      {selectedDocument && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-xl shadow-xl max-w-4xl w-full max-h-[90vh] overflow-hidden">
            <div className="p-4 border-b border-gray-200 flex justify-between items-center">
              <h3 className="text-lg font-semibold text-gray-900">{selectedDocument.name}</h3>
              <button
                onClick={() => setSelectedDocument(null)}
                className="p-2 text-gray-400 hover:text-gray-600"
              >
                <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
                </svg>
              </button>
            </div>
            <div className="p-4">
              {selectedDocument.url?.endsWith('.pdf') ? (
                <iframe
                  src={getDocumentViewUrl(selectedDocument.url)}
                  className="w-full h-96"
                  title="Document"
                />
              ) : (
                <img
                  src={getDocumentViewUrl(selectedDocument.url)}
                  alt={selectedDocument.name}
                  className="max-w-full max-h-96 mx-auto"
                />
              )}
            </div>
            <div className="p-4 border-t border-gray-200 flex justify-end gap-3">
              <button
                onClick={() => setSelectedDocument(null)}
                className="px-4 py-2 border border-gray-300 rounded-lg hover:bg-gray-50"
              >
                Close
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Reject Modal */}
      {showRejectModal && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-xl shadow-xl max-w-md w-full">
            <div className="p-6">
              <h3 className="text-lg font-semibold text-gray-900 mb-4">Reject Document</h3>
              <p className="text-sm text-gray-600 mb-4">
                Please provide a reason for rejection. The partner will need to re-upload the document.
              </p>
              <textarea
                value={rejectReason}
                onChange={(e) => setRejectReason(e.target.value)}
                placeholder="e.g., Image is not clear, Document is expired, Wrong document type..."
                className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-red-500 focus:border-red-500"
                rows={3}
              />
            </div>
            <div className="p-4 border-t border-gray-200 flex justify-end gap-3">
              <button
                onClick={() => {
                  setShowRejectModal(false);
                  setRejectReason('');
                }}
                className="px-4 py-2 border border-gray-300 rounded-lg hover:bg-gray-50"
              >
                Cancel
              </button>
              <button
                onClick={handleRejectDocument}
                disabled={processing || !rejectReason.trim()}
                className="px-4 py-2 bg-red-600 text-white rounded-lg hover:bg-red-700 disabled:opacity-50"
              >
                {processing ? 'Rejecting...' : 'Reject Document'}
              </button>
            </div>
          </div>
        </div>
      )}
    </DashboardLayout>
  );
};

export default KYCVerification;