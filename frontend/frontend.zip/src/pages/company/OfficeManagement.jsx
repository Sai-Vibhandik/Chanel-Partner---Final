import { useState, useEffect } from 'react';
import DashboardLayout from '../../components/layout/DashboardLayout';
import { sidebarConfig } from '../../config/sidebar';
import api from '../../utils/api';

const OfficeManagement = ({ role = 'company_superadmin' }) => {
  const config = role === 'partner_manager' ? sidebarConfig.partner_manager : sidebarConfig.company_superadmin;

  const [activeTab, setActiveTab] = useState('offices');
  const [offices, setOffices] = useState([]);
  const [slots, setSlots] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [success, setSuccess] = useState('');

  // Modal states
  const [showOfficeModal, setShowOfficeModal] = useState(false);
  const [showSlotModal, setShowSlotModal] = useState(false);
  const [editingOffice, setEditingOffice] = useState(null);
  const [editingSlot, setEditingSlot] = useState(null);

  // Office form
  const [officeForm, setOfficeForm] = useState({
    name: '',
    address: { street: '', city: '', state: '', country: '', zipCode: '' },
    phone: '',
    email: '',
    googleMapsUrl: '',
    operatingHours: { start: '09:00', end: '18:00' }
  });

  // Slot form
  const [slotForm, setSlotForm] = useState({
    name: '',
    officeId: '',
    dayOfWeek: 1,
    startTime: '09:00',
    endTime: '10:00',
    maxBookings: 1,
    durationMinutes: 60
  });

  const days = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];

  useEffect(() => {
    fetchData();
  }, []);

  const fetchData = async () => {
    try {
      setLoading(true);
      const [officesRes, slotsRes] = await Promise.all([
        api.get('/offices'),
        api.get('/offices/slots')
      ]);
      setOffices(officesRes.data.data.offices);
      setSlots(slotsRes.data.data.slots);
    } catch (err) {
      setError(err.response?.data?.message || 'Failed to load data');
    } finally {
      setLoading(false);
    }
  };

  // Office CRUD
  const handleCreateOffice = async () => {
    try {
      setError('');
      const res = await api.post('/offices', officeForm);
      setOffices([...offices, res.data.data.office]);
      setShowOfficeModal(false);
      resetOfficeForm();
      setSuccess('Office location created successfully');
    } catch (err) {
      setError(err.response?.data?.message || 'Failed to create office');
    }
  };

  const handleUpdateOffice = async () => {
    try {
      setError('');
      const res = await api.put(`/offices/${editingOffice._id}`, officeForm);
      setOffices(offices.map(o => o._id === editingOffice._id ? res.data.data.office : o));
      setShowOfficeModal(false);
      setEditingOffice(null);
      resetOfficeForm();
      setSuccess('Office location updated successfully');
    } catch (err) {
      setError(err.response?.data?.message || 'Failed to update office');
    }
  };

  const handleDeleteOffice = async (id) => {
    if (!window.confirm('Are you sure you want to delete this office location?')) return;
    try {
      await api.delete(`/offices/${id}`);
      setOffices(offices.filter(o => o._id !== id));
      setSuccess('Office location deleted successfully');
    } catch (err) {
      setError(err.response?.data?.message || 'Failed to delete office');
    }
  };

  // Slot CRUD
  const handleCreateSlot = async () => {
    try {
      setError('');
      const res = await api.post('/offices/slots', {
        ...slotForm,
        officeId: slotForm.officeId || null
      });
      setSlots([...slots, res.data.data.slot]);
      setShowSlotModal(false);
      resetSlotForm();
      setSuccess('Time slot created successfully');
    } catch (err) {
      setError(err.response?.data?.message || 'Failed to create time slot');
    }
  };

  const handleUpdateSlot = async () => {
    try {
      setError('');
      const res = await api.put(`/offices/slots/${editingSlot._id}`, {
        ...slotForm,
        officeId: slotForm.officeId || null
      });
      setSlots(slots.map(s => s._id === editingSlot._id ? res.data.data.slot : s));
      setShowSlotModal(false);
      setEditingSlot(null);
      resetSlotForm();
      setSuccess('Time slot updated successfully');
    } catch (err) {
      setError(err.response?.data?.message || 'Failed to update time slot');
    }
  };

  const handleDeleteSlot = async (id) => {
    if (!window.confirm('Are you sure you want to delete this time slot?')) return;
    try {
      await api.delete(`/offices/slots/${id}`);
      setSlots(slots.filter(s => s._id !== id));
      setSuccess('Time slot deleted successfully');
    } catch (err) {
      setError(err.response?.data?.message || 'Failed to delete time slot');
    }
  };

  const resetOfficeForm = () => {
    setOfficeForm({
      name: '',
      address: { street: '', city: '', state: '', country: '', zipCode: '' },
      phone: '',
      email: '',
      googleMapsUrl: '',
      operatingHours: { start: '09:00', end: '18:00' }
    });
  };

  const resetSlotForm = () => {
    setSlotForm({
      name: '',
      officeId: '',
      dayOfWeek: 1,
      startTime: '09:00',
      endTime: '10:00',
      maxBookings: 1,
      durationMinutes: 60
    });
  };

  const openEditOffice = (office) => {
    setEditingOffice(office);
    setOfficeForm({
      name: office.name,
      address: office.address || { street: '', city: '', state: '', country: '', zipCode: '' },
      phone: office.phone || '',
      email: office.email || '',
      googleMapsUrl: office.googleMapsUrl || '',
      operatingHours: office.operatingHours || { start: '09:00', end: '18:00' }
    });
    setShowOfficeModal(true);
  };

  const openEditSlot = (slot) => {
    setEditingSlot(slot);
    setSlotForm({
      name: slot.name,
      officeId: slot.officeId?._id || slot.officeId || '',
      dayOfWeek: slot.dayOfWeek,
      startTime: slot.startTime,
      endTime: slot.endTime,
      maxBookings: slot.maxBookings,
      durationMinutes: slot.durationMinutes
    });
    setShowSlotModal(true);
  };

  const toggleOfficeStatus = async (office) => {
    try {
      const res = await api.put(`/offices/${office._id}`, {
        isActive: !office.isActive
      });
      setOffices(offices.map(o => o._id === office._id ? res.data.data.office : o));
      setSuccess(`Office ${!office.isActive ? 'activated' : 'deactivated'} successfully`);
    } catch (err) {
      setError(err.response?.data?.message || 'Failed to update office status');
    }
  };

  const toggleSlotStatus = async (slot) => {
    try {
      const res = await api.put(`/offices/slots/${slot._id}`, {
        isActive: !slot.isActive
      });
      setSlots(slots.map(s => s._id === slot._id ? res.data.data.slot : s));
      setSuccess(`Time slot ${!slot.isActive ? 'activated' : 'deactivated'} successfully`);
    } catch (err) {
      setError(err.response?.data?.message || 'Failed to update slot status');
    }
  };

  if (loading) {
    return (
      <DashboardLayout sidebarLinks={config.links} title="Office Management" subtitle="Loading..." color={config.color}>
        <div className="flex items-center justify-center min-h-64">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-indigo-600"></div>
        </div>
      </DashboardLayout>
    );
  }

  return (
    <DashboardLayout sidebarLinks={config.links} title="Office Management" subtitle="Manage office locations and time slots" color={config.color}>
      {/* Messages */}
      {error && <div className="mb-6 p-4 bg-red-50 border border-red-200 rounded-lg text-red-700">{error}</div>}
      {success && <div className="mb-6 p-4 bg-green-50 border border-green-200 rounded-lg text-green-700">{success}</div>}

      {/* Tabs */}
      <div className="flex gap-4 mb-6">
        <button
          onClick={() => setActiveTab('offices')}
          className={`px-4 py-2 rounded-lg font-medium ${
            activeTab === 'offices'
              ? 'bg-indigo-600 text-white'
              : 'bg-white text-gray-700 border border-gray-300 hover:bg-gray-50'
          }`}
        >
          Office Locations
        </button>
        <button
          onClick={() => setActiveTab('slots')}
          className={`px-4 py-2 rounded-lg font-medium ${
            activeTab === 'slots'
              ? 'bg-indigo-600 text-white'
              : 'bg-white text-gray-700 border border-gray-300 hover:bg-gray-50'
          }`}
        >
          Time Slots
        </button>
      </div>

      {/* Offices Tab */}
      {activeTab === 'offices' && (
        <div>
          <div className="flex justify-between items-center mb-6">
            <h2 className="text-xl font-semibold text-gray-900">Office Locations</h2>
            <button
              onClick={() => {
                resetOfficeForm();
                setEditingOffice(null);
                setShowOfficeModal(true);
              }}
              className="px-4 py-2 bg-indigo-600 text-white rounded-lg hover:bg-indigo-700 flex items-center gap-2"
            >
              <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 4v16m8-8H4" />
              </svg>
              Add Office
            </button>
          </div>

          {offices.length === 0 ? (
            <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-10 text-center">
              <svg className="w-16 h-16 text-gray-300 mx-auto mb-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M19 21V5a2 2 0 00-2-2H7a2 2 0 00-2 2v16m14 0h2m-2 0h-5m-9 0H3m2 0h5M9 7h1m-1 4h1m4-4h1m-1 4h1m-5 10v-5a1 1 0 011-1h2a1 1 0 011 1v5m-4 0h4" />
              </svg>
              <h3 className="text-lg font-medium text-gray-900 mb-2">No Office Locations</h3>
              <p className="text-gray-500 mb-4">Add office locations for partners to schedule visits.</p>
              <button
                onClick={() => setShowOfficeModal(true)}
                className="px-4 py-2 bg-indigo-600 text-white rounded-lg hover:bg-indigo-700"
              >
                Add First Office
              </button>
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {offices.map((office) => (
                <div
                  key={office._id}
                  className={`bg-white rounded-xl shadow-sm border overflow-hidden ${
                    office.isActive ? 'border-gray-100' : 'border-red-200 bg-red-50'
                  }`}
                >
                  <div className="p-5">
                    <div className="flex items-start justify-between mb-3">
                      <h3 className="font-semibold text-gray-900">{office.name}</h3>
                      <span className={`px-2 py-1 text-xs rounded-full ${
                        office.isActive ? 'bg-green-100 text-green-800' : 'bg-red-100 text-red-800'
                      }`}>
                        {office.isActive ? 'Active' : 'Inactive'}
                      </span>
                    </div>

                    <div className="space-y-2 text-sm text-gray-600">
                      <div className="flex items-start gap-2">
                        <svg className="w-4 h-4 mt-0.5 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M17.657 16.657L13.414 20.9a1.998 1.998 0 01-2.827 0l-4.244-4.243a8 8 0 1111.314 0z" />
                        </svg>
                        <span>{office.address?.street}, {office.address?.city}</span>
                      </div>
                      {office.phone && (
                        <div className="flex items-center gap-2">
                          <svg className="w-4 h-4 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 5a2 2 0 012-2h3.28a1 1 0 01.948.684l1.498 4.493a1 1 0 01-.502 1.21l-2.257 1.13a11.042 11.042 0 005.516 5.516l1.13-2.257a1 1 0 011.21-.502l4.493 1.498a1 1 0 01.684.949V19a2 2 0 01-2 2h-1C9.716 21 3 14.284 3 6V5z" />
                          </svg>
                          <span>{office.phone}</span>
                        </div>
                      )}
                      <div className="flex items-center gap-2">
                        <svg className="w-4 h-4 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z" />
                        </svg>
                        <span>{office.operatingHours?.start} - {office.operatingHours?.end}</span>
                      </div>
                    </div>

                    {office.googleMapsUrl && (
                      <a
                        href={office.googleMapsUrl}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="mt-3 inline-flex items-center gap-1 text-indigo-600 hover:text-indigo-800 text-sm"
                      >
                        <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M17.657 16.657L13.414 20.9a1.998 1.998 0 01-2.827 0l-4.244-4.243a8 8 0 1111.314 0z" />
                        </svg>
                        View on Maps
                      </a>
                    )}
                  </div>

                  <div className="px-5 py-3 bg-gray-50 border-t border-gray-100 flex justify-between">
                    <button
                      onClick={() => openEditOffice(office)}
                      className="text-indigo-600 hover:text-indigo-800 text-sm font-medium"
                    >
                      Edit
                    </button>
                    <button
                      onClick={() => toggleOfficeStatus(office)}
                      className={`text-sm font-medium ${
                        office.isActive ? 'text-red-600 hover:text-red-800' : 'text-green-600 hover:text-green-800'
                      }`}
                    >
                      {office.isActive ? 'Deactivate' : 'Activate'}
                    </button>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      )}

      {/* Time Slots Tab */}
      {activeTab === 'slots' && (
        <div>
          <div className="flex justify-between items-center mb-6">
            <h2 className="text-xl font-semibold text-gray-900">Time Slots</h2>
            <button
              onClick={() => {
                resetSlotForm();
                setEditingSlot(null);
                setShowSlotModal(true);
              }}
              className="px-4 py-2 bg-indigo-600 text-white rounded-lg hover:bg-indigo-700 flex items-center gap-2"
            >
              <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 4v16m8-8H4" />
              </svg>
              Add Time Slot
            </button>
          </div>

          {slots.length === 0 ? (
            <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-10 text-center">
              <svg className="w-16 h-16 text-gray-300 mx-auto mb-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z" />
              </svg>
              <h3 className="text-lg font-medium text-gray-900 mb-2">No Time Slots</h3>
              <p className="text-gray-500 mb-4">Create time slots for visit scheduling.</p>
              <button
                onClick={() => setShowSlotModal(true)}
                className="px-4 py-2 bg-indigo-600 text-white rounded-lg hover:bg-indigo-700"
              >
                Add First Time Slot
              </button>
            </div>
          ) : (
            <div className="bg-white rounded-xl shadow-sm border border-gray-100 overflow-hidden">
              <table className="min-w-full divide-y divide-gray-200">
                <thead className="bg-gray-50">
                  <tr>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Name</th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Day</th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Time</th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Office</th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Max Bookings</th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Status</th>
                    <th className="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase">Actions</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-gray-200">
                  {slots.map((slot) => (
                    <tr key={slot._id} className="hover:bg-gray-50">
                      <td className="px-6 py-4 whitespace-nowrap">
                        <span className="font-medium text-gray-900">{slot.name}</span>
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap">
                        <span className="text-gray-600">{slot.dayName}</span>
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap">
                        <span className="text-gray-600">{slot.startTime} - {slot.endTime}</span>
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap">
                        <span className="text-gray-600">
                          {slot.officeId?.name || 'All Offices'}
                        </span>
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap">
                        <span className="text-gray-600">{slot.maxBookings}</span>
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap">
                        <span className={`px-2 py-1 text-xs rounded-full ${
                          slot.isActive ? 'bg-green-100 text-green-800' : 'bg-red-100 text-red-800'
                        }`}>
                          {slot.isActive ? 'Active' : 'Inactive'}
                        </span>
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-right">
                        <button
                          onClick={() => openEditSlot(slot)}
                          className="text-indigo-600 hover:text-indigo-800 text-sm font-medium mr-3"
                        >
                          Edit
                        </button>
                        <button
                          onClick={() => toggleSlotStatus(slot)}
                          className={`text-sm font-medium ${
                            slot.isActive ? 'text-red-600 hover:text-red-800' : 'text-green-600 hover:text-green-800'
                          }`}
                        >
                          {slot.isActive ? 'Deactivate' : 'Activate'}
                        </button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>
      )}

      {/* Office Modal */}
      {showOfficeModal && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-xl shadow-xl max-w-2xl w-full max-h-[90vh] overflow-y-auto">
            <div className="p-6 border-b border-gray-200">
              <h3 className="text-xl font-semibold text-gray-900">
                {editingOffice ? 'Edit Office Location' : 'Add Office Location'}
              </h3>
            </div>

            <div className="p-6 space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Office Name *</label>
                <input
                  type="text"
                  value={officeForm.name}
                  onChange={(e) => setOfficeForm({ ...officeForm, name: e.target.value })}
                  className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500"
                  placeholder="e.g., Main Office, Branch Office"
                />
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div className="col-span-2">
                  <label className="block text-sm font-medium text-gray-700 mb-1">Street Address</label>
                  <input
                    type="text"
                    value={officeForm.address.street}
                    onChange={(e) => setOfficeForm({
                      ...officeForm,
                      address: { ...officeForm.address, street: e.target.value }
                    })}
                    className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">City *</label>
                  <input
                    type="text"
                    value={officeForm.address.city}
                    onChange={(e) => setOfficeForm({
                      ...officeForm,
                      address: { ...officeForm.address, city: e.target.value }
                    })}
                    className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">State</label>
                  <input
                    type="text"
                    value={officeForm.address.state}
                    onChange={(e) => setOfficeForm({
                      ...officeForm,
                      address: { ...officeForm.address, state: e.target.value }
                    })}
                    className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Country *</label>
                  <input
                    type="text"
                    value={officeForm.address.country}
                    onChange={(e) => setOfficeForm({
                      ...officeForm,
                      address: { ...officeForm.address, country: e.target.value }
                    })}
                    className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Zip Code</label>
                  <input
                    type="text"
                    value={officeForm.address.zipCode}
                    onChange={(e) => setOfficeForm({
                      ...officeForm,
                      address: { ...officeForm.address, zipCode: e.target.value }
                    })}
                    className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Phone</label>
                  <input
                    type="tel"
                    value={officeForm.phone}
                    onChange={(e) => setOfficeForm({ ...officeForm, phone: e.target.value })}
                    className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Email</label>
                  <input
                    type="email"
                    value={officeForm.email}
                    onChange={(e) => setOfficeForm({ ...officeForm, email: e.target.value })}
                    className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500"
                  />
                </div>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Google Maps URL</label>
                <input
                  type="url"
                  value={officeForm.googleMapsUrl}
                  onChange={(e) => setOfficeForm({ ...officeForm, googleMapsUrl: e.target.value })}
                  className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500"
                  placeholder="https://maps.google.com/..."
                />
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Opening Time</label>
                  <input
                    type="time"
                    value={officeForm.operatingHours.start}
                    onChange={(e) => setOfficeForm({
                      ...officeForm,
                      operatingHours: { ...officeForm.operatingHours, start: e.target.value }
                    })}
                    className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Closing Time</label>
                  <input
                    type="time"
                    value={officeForm.operatingHours.end}
                    onChange={(e) => setOfficeForm({
                      ...officeForm,
                      operatingHours: { ...officeForm.operatingHours, end: e.target.value }
                    })}
                    className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500"
                  />
                </div>
              </div>
            </div>

            <div className="p-6 border-t border-gray-200 flex justify-end gap-3">
              <button
                onClick={() => {
                  setShowOfficeModal(false);
                  setEditingOffice(null);
                  resetOfficeForm();
                }}
                className="px-4 py-2 border border-gray-300 rounded-lg hover:bg-gray-50"
              >
                Cancel
              </button>
              <button
                onClick={editingOffice ? handleUpdateOffice : handleCreateOffice}
                className="px-4 py-2 bg-indigo-600 text-white rounded-lg hover:bg-indigo-700"
              >
                {editingOffice ? 'Update' : 'Create'}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Time Slot Modal */}
      {showSlotModal && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-xl shadow-xl max-w-lg w-full">
            <div className="p-6 border-b border-gray-200">
              <h3 className="text-xl font-semibold text-gray-900">
                {editingSlot ? 'Edit Time Slot' : 'Add Time Slot'}
              </h3>
            </div>

            <div className="p-6 space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Slot Name *</label>
                <input
                  type="text"
                  value={slotForm.name}
                  onChange={(e) => setSlotForm({ ...slotForm, name: e.target.value })}
                  className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500"
                  placeholder="e.g., Morning Slot, Afternoon Slot"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Office (Optional)</label>
                <select
                  value={slotForm.officeId}
                  onChange={(e) => setSlotForm({ ...slotForm, officeId: e.target.value })}
                  className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500"
                >
                  <option value="">All Offices</option>
                  {offices.filter(o => o.isActive).map((office) => (
                    <option key={office._id} value={office._id}>{office.name}</option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Day of Week *</label>
                <select
                  value={slotForm.dayOfWeek}
                  onChange={(e) => setSlotForm({ ...slotForm, dayOfWeek: parseInt(e.target.value) })}
                  className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500"
                >
                  {days.map((day, index) => (
                    <option key={index} value={index}>{day}</option>
                  ))}
                </select>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Start Time *</label>
                  <input
                    type="time"
                    value={slotForm.startTime}
                    onChange={(e) => setSlotForm({ ...slotForm, startTime: e.target.value })}
                    className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">End Time *</label>
                  <input
                    type="time"
                    value={slotForm.endTime}
                    onChange={(e) => setSlotForm({ ...slotForm, endTime: e.target.value })}
                    className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Max Bookings</label>
                  <input
                    type="number"
                    value={slotForm.maxBookings}
                    onChange={(e) => setSlotForm({ ...slotForm, maxBookings: parseInt(e.target.value) || 1 })}
                    className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500"
                    min="1"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Duration (mins)</label>
                  <input
                    type="number"
                    value={slotForm.durationMinutes}
                    onChange={(e) => setSlotForm({ ...slotForm, durationMinutes: parseInt(e.target.value) || 60 })}
                    className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500"
                    min="15"
                  />
                </div>
              </div>
            </div>

            <div className="p-6 border-t border-gray-200 flex justify-end gap-3">
              <button
                onClick={() => {
                  setShowSlotModal(false);
                  setEditingSlot(null);
                  resetSlotForm();
                }}
                className="px-4 py-2 border border-gray-300 rounded-lg hover:bg-gray-50"
              >
                Cancel
              </button>
              <button
                onClick={editingSlot ? handleUpdateSlot : handleCreateSlot}
                className="px-4 py-2 bg-indigo-600 text-white rounded-lg hover:bg-indigo-700"
              >
                {editingSlot ? 'Update' : 'Create'}
              </button>
            </div>
          </div>
        </div>
      )}
    </DashboardLayout>
  );
};

export default OfficeManagement;