import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import DashboardLayout from '../../components/layout/DashboardLayout';
import { sidebarConfig } from '../../config/sidebar';
import api from '../../utils/api';

const PartnerManagerVisits = () => {
  const config = sidebarConfig.partner_manager;
  const navigate = useNavigate();

  const [visits, setVisits] = useState([]);
  const [stats, setStats] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [success, setSuccess] = useState('');
  const [processing, setProcessing] = useState(false);

  const [filters, setFilters] = useState({
    status: '',
    date: '',
    partnerId: ''
  });

  const [partners, setPartners] = useState([]);

  useEffect(() => {
    fetchVisits();
    fetchStats();
    fetchPartners();
  }, [filters]);

  const fetchVisits = async () => {
    try {
      setLoading(true);
      const params = new URLSearchParams();
      if (filters.status) params.append('status', filters.status);
      if (filters.date) params.append('date', filters.date);

      const response = await api.get(`/visits/company?${params.toString()}`);
      setVisits(response.data.data.visits);
    } catch (err) {
      setError(err.response?.data?.message || 'Failed to load visits');
    } finally {
      setLoading(false);
    }
  };

  const fetchStats = async () => {
    try {
      const response = await api.get('/visits/stats');
      setStats(response.data.data);
    } catch (err) {
      console.error('Failed to load stats');
    }
  };

  const fetchPartners = async () => {
    try {
      const response = await api.get('/partners');
      setPartners(response.data.data.partners);
    } catch (err) {
      console.error('Failed to load partners');
    }
  };

  const handleApproveVisit = async (visitId) => {
    try {
      setProcessing(true);
      await api.put(`/visits/${visitId}/approve`);
      setSuccess('Visit approved successfully');
      fetchVisits();
      fetchStats();
    } catch (err) {
      setError(err.response?.data?.message || 'Failed to approve visit');
    } finally {
      setProcessing(false);
    }
  };

  const handleRejectVisit = async (visitId, reason) => {
    try {
      setProcessing(true);
      await api.put(`/visits/${visitId}/reject`, { reason });
      setSuccess('Visit rejected');
      fetchVisits();
      fetchStats();
    } catch (err) {
      setError(err.response?.data?.message || 'Failed to reject visit');
    } finally {
      setProcessing(false);
    }
  };

  const handleCompleteVisit = async (visitId) => {
    try {
      setProcessing(true);
      await api.put(`/visits/${visitId}/complete`);
      setSuccess('Visit marked as completed');
      fetchVisits();
      fetchStats();
    } catch (err) {
      setError(err.response?.data?.message || 'Failed to complete visit');
    } finally {
      setProcessing(false);
    }
  };

  const formatCurrency = (amount, currency = 'INR') => {
    const symbol = currency === 'INR' ? '₹' : 'AED ';
    if (amount >= 10000000) {
      return `${symbol}${(amount / 10000000).toFixed(2)} Cr`;
    } else if (amount >= 100000) {
      return `${symbol}${(amount / 100000).toFixed(2)} Lac`;
    }
    return `${symbol}${amount?.toLocaleString() || '0'}`;
  };

  const getStatusBadge = (status) => {
    const styles = {
      pending: 'bg-yellow-100 text-yellow-800',
      approved: 'bg-blue-100 text-blue-800',
      rejected: 'bg-red-100 text-red-800',
      completed: 'bg-green-100 text-green-800',
      cancelled: 'bg-gray-100 text-gray-800',
      deal_closed: 'bg-purple-100 text-purple-800'
    };
    return styles[status] || 'bg-gray-100 text-gray-800';
  };

  const getStatusText = (status) => {
    const texts = {
      pending: 'Pending Approval',
      approved: 'Approved',
      rejected: 'Rejected',
      completed: 'Completed',
      cancelled: 'Cancelled',
      deal_closed: 'Deal Closed'
    };
    return texts[status] || status;
  };

  const filteredVisits = filters.partnerId
    ? visits.filter(v => v.partner?._id === filters.partnerId)
    : visits;

  if (loading && visits.length === 0) {
    return (
      <DashboardLayout sidebarLinks={config.links} title="Visits" subtitle="Loading..." color={config.color}>
        <div className="flex items-center justify-center min-h-64">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-indigo-600"></div>
        </div>
      </DashboardLayout>
    );
  }

  return (
    <DashboardLayout sidebarLinks={config.links} title="Visit Management" subtitle="Manage partner visits" color={config.color}>
      {/* Messages */}
      {error && (
        <div className="mb-6 p-4 bg-red-50 border border-red-200 rounded-lg text-red-700">{error}</div>
      )}
      {success && (
        <div className="mb-6 p-4 bg-green-50 border border-green-200 rounded-lg text-green-700">{success}</div>
      )}

      {/* Stats */}
      {stats && (
        <div className="grid grid-cols-2 md:grid-cols-5 gap-4 mb-8">
          <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-4">
            <p className="text-sm text-gray-500">Pending Approval</p>
            <p className="text-2xl font-bold text-yellow-600 mt-1">{stats.pendingApprovals || 0}</p>
          </div>
          <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-4">
            <p className="text-sm text-gray-500">Approved</p>
            <p className="text-2xl font-bold text-blue-600 mt-1">{stats.approved || 0}</p>
          </div>
          <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-4">
            <p className="text-sm text-gray-500">Today's Visits</p>
            <p className="text-2xl font-bold text-green-600 mt-1">{stats.todayVisits || 0}</p>
          </div>
          <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-4">
            <p className="text-sm text-gray-500">Completed</p>
            <p className="text-2xl font-bold text-purple-600 mt-1">{stats.completed || 0}</p>
          </div>
          <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-4">
            <p className="text-sm text-gray-500">Deals Closed</p>
            <p className="text-2xl font-bold text-indigo-600 mt-1">{stats.dealsClosed || 0}</p>
          </div>
        </div>
      )}

      {/* Filters */}
      <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-4 mb-6">
        <div className="flex flex-wrap gap-4">
          <select
            value={filters.status}
            onChange={(e) => setFilters({ ...filters, status: e.target.value })}
            className="px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500"
          >
            <option value="">All Status</option>
            <option value="pending">Pending Approval</option>
            <option value="approved">Approved</option>
            <option value="completed">Completed</option>
            <option value="deal_closed">Deal Closed</option>
          </select>
          <select
            value={filters.partnerId}
            onChange={(e) => setFilters({ ...filters, partnerId: e.target.value })}
            className="px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500"
          >
            <option value="">All Partners</option>
            {partners.map(p => (
              <option key={p._id} value={p._id}>{p.firstName} {p.lastName}</option>
            ))}
          </select>
          <input
            type="date"
            value={filters.date}
            onChange={(e) => setFilters({ ...filters, date: e.target.value })}
            className="px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500"
          />
        </div>
      </div>

      {/* Visits List */}
      <div className="bg-white rounded-xl shadow-sm border border-gray-100 overflow-hidden">
        {filteredVisits.length === 0 ? (
          <div className="p-8 text-center">
            <svg className="w-16 h-16 mx-auto text-gray-300 mb-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8 7V3m8 4V3m-9 8h10M5 21h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z" />
            </svg>
            <p className="text-gray-500">No visits found</p>
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead className="bg-gray-50 border-b border-gray-200">
                <tr>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Partner</th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Property</th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Date & Time</th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Client</th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Status</th>
                  <th className="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-gray-200">
                {filteredVisits.map((visit) => (
                  <tr key={visit._id} className="hover:bg-gray-50">
                    <td className="px-6 py-4 whitespace-nowrap">
                      <div className="text-sm font-medium text-gray-900">
                        {visit.partner?.firstName} {visit.partner?.lastName}
                      </div>
                      <div className="text-sm text-gray-500">{visit.partner?.email}</div>
                    </td>
                    <td className="px-6 py-4">
                      <div className="text-sm font-medium text-gray-900">{visit.property?.name}</div>
                      <div className="text-sm text-gray-500">
                        {formatCurrency(visit.property?.pricing?.basePrice, visit.property?.pricing?.currency)}
                      </div>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <div className="text-sm font-medium text-gray-900">
                        {new Date(visit.scheduledDate).toLocaleDateString()}
                      </div>
                      <div className="text-sm text-gray-500">{visit.scheduledTime}</div>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <div className="text-sm font-medium text-gray-900">{visit.clientDetails?.name}</div>
                      <div className="text-sm text-gray-500">{visit.clientDetails?.phone}</div>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <span className={`px-2 py-1 rounded text-xs font-medium ${getStatusBadge(visit.status)}`}>
                        {getStatusText(visit.status)}
                      </span>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-right">
                      <div className="flex justify-end gap-2">
                        {visit.status === 'pending' && (
                          <>
                            <button
                              onClick={() => handleApproveVisit(visit._id)}
                              disabled={processing}
                              className="px-3 py-1 bg-green-600 text-white text-xs rounded hover:bg-green-700 disabled:opacity-50"
                            >
                              Approve
                            </button>
                            <button
                              onClick={() => {
                                const reason = prompt('Enter rejection reason:');
                                if (reason) handleRejectVisit(visit._id, reason);
                              }}
                              className="px-3 py-1 bg-red-600 text-white text-xs rounded hover:bg-red-700"
                            >
                              Reject
                            </button>
                          </>
                        )}
                        {visit.status === 'approved' && (
                          <button
                            onClick={() => handleCompleteVisit(visit._id)}
                            disabled={processing}
                            className="px-3 py-1 bg-indigo-600 text-white text-xs rounded hover:bg-indigo-700 disabled:opacity-50"
                          >
                            Complete
                          </button>
                        )}
                        <button
                          onClick={() => navigate(`/partner-manager/visits/${visit._id}`)}
                          className="px-3 py-1 text-indigo-600 text-xs hover:text-indigo-700"
                        >
                          View
                        </button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </DashboardLayout>
  );
};

export default PartnerManagerVisits;